import { useState, useEffect, useCallback } from 'react';
import apiClient from '@/lib/apiClient';

type ApiEndpoint =
  | '/api/signals'
  | '/api/positions'
  | '/api/market-data'
  | '/api/guardian/status'
  | '/api/news'
  | '/api/sessions'
  | '/api/backtest'
  | '/api/screener'
  | '/api/performance';

interface UseApiDataOptions<T> {
  endpoint: ApiEndpoint;
  fallback: T;
  intervalMs?: number;
  enabled?: boolean;
}

export function useApiData<T>({
  endpoint,
  fallback,
  intervalMs = 0,
  enabled = true,
}: UseApiDataOptions<T>) {
  const [data, setData] = useState<T>(fallback);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    if (!enabled) return;
    setLoading(true);
    setError(null);
    try {
      const result = (await apiClient.getJson(endpoint)) as T;
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      // Keep fallback data on error — don't overwrite
    } finally {
      setLoading(false);
    }
  }, [endpoint, enabled]);

  useEffect(() => {
    fetchData();
    if (intervalMs > 0) {
      const interval = setInterval(fetchData, intervalMs);
      return () => clearInterval(interval);
    }
  }, [fetchData, intervalMs]);

  return { data, loading, error, refetch: fetchData };
}

export function usePostMutation<T>(endpoint: ApiEndpoint) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mutate = useCallback(
    async (payload?: Record<string, unknown>): Promise<T | null> => {
      setLoading(true);
      setError(null);
      try {
        const result = (await apiClient.postJson(endpoint, payload)) as T;
        return result;
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
        return null;
      } finally {
        setLoading(false);
      }
    },
    [endpoint]
  );

  return { mutate, loading, error };
}
