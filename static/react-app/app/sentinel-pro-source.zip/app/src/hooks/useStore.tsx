import { createContext, useContext, useState, useCallback, useRef, useEffect } from 'react';
import type { PanelId, Signal, Position, MarketData, GuardianStatus, NewsItem, SessionHours } from '@/types';
import {
  generateSignals, generatePositions, generateMarketData,
  generateGuardianStatus, generateNews, generateSessionHours,
  getLivePrice
} from '@/data/mockData';
import { syncPricesToGlobal, syncSignalsToGlobal } from '@/lib/globalState';

interface AppState {
  activePanel: PanelId;
  signals: Signal[];
  positions: Position[];
  marketData: MarketData[];
  guardian: GuardianStatus;
  news: NewsItem[];
  sessions: SessionHours[];
  isAutoTrade: boolean;
  isTestMode: boolean;
  isLoading: boolean;
  toast: { message: string; type: 'success' | 'error' | 'info' } | null;
}

interface AppActions {
  setActivePanel: (panel: PanelId) => void;
  refreshSignals: () => void;
  refreshPositions: () => void;
  refreshMarketData: () => void;
  refreshGuardian: () => void;
  toggleAutoTrade: () => void;
  toggleTestMode: () => void;
  executeSignal: (signalId: string) => void;
  closePosition: (positionId: string) => void;
  showToast: (message: string, type: 'success' | 'error' | 'info') => void;
  getLivePrice: (pair: string) => number;
}

const StoreContext = createContext<(AppState & AppActions) | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [activePanel, setActivePanel] = useState<PanelId>('dashboard');
  const [signals, setSignals] = useState<Signal[]>(generateSignals());
  const [positions, setPositions] = useState<Position[]>(generatePositions());
  const [marketData, setMarketData] = useState<MarketData[]>(generateMarketData());
  const [guardian, setGuardian] = useState<GuardianStatus>(generateGuardianStatus());
  const [news] = useState<NewsItem[]>(generateNews());
  const [sessions] = useState<SessionHours[]>(generateSessionHours());
  const [isAutoTrade, setIsAutoTrade] = useState(false);
  const [isTestMode, setIsTestMode] = useState(false);
  const [isLoading] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const toastTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info') => {
    if (toastTimeout.current !== null) clearTimeout(toastTimeout.current);
    setToast({ message, type });
    toastTimeout.current = setTimeout(() => setToast(null), 3000);
  }, []);

  const refreshSignals = useCallback(() => {
    setSignals(generateSignals());
    showToast('Signals refreshed', 'success');
  }, [showToast]);

  const refreshPositions = useCallback(() => {
    setPositions(generatePositions());
    showToast('Positions refreshed', 'success');
  }, [showToast]);

  const refreshMarketData = useCallback(() => {
    setMarketData(generateMarketData());
  }, []);

  const refreshGuardian = useCallback(() => {
    setGuardian(generateGuardianStatus());
  }, []);

  const toggleAutoTrade = useCallback(() => {
    setIsAutoTrade(prev => {
      showToast(!prev ? 'Auto-trade enabled' : 'Auto-trade disabled', 'info');
      return !prev;
    });
  }, [showToast]);

  const toggleTestMode = useCallback(() => {
    setIsTestMode(prev => {
      showToast(!prev ? 'Test mode enabled' : 'Test mode disabled', 'info');
      return !prev;
    });
  }, [showToast]);

  const executeSignal = useCallback((signalId: string) => {
    const signal = signals.find(s => s.id === signalId);
    if (!signal) return;
    const newPosition: Position = {
      id: `pos_${Date.now()}`,
      pair: signal.pair,
      direction: signal.direction,
      entry: signal.entry,
      size: 0.5,
      sl: signal.sl,
      tp: signal.tp,
      pnl: 0,
      pnlPercent: 0,
      openTime: new Date().toISOString(),
      broker: 'MT5',
      type: 'market',
      status: 'open',
    };
    setPositions(prev => [newPosition, ...prev]);
    showToast(`Executed ${signal.direction} ${signal.pair}`, 'success');
  }, [signals, showToast]);

  const closePosition = useCallback((positionId: string) => {
    setPositions(prev => prev.filter(p => p.id !== positionId));
    showToast('Position closed', 'info');
  }, [showToast]);

  useEffect(() => {
    const interval = setInterval(() => {
      setMarketData(generateMarketData());
      setGuardian(generateGuardianStatus());
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Sync React state to global window.AppState
  useEffect(() => {
    syncSignalsToGlobal(signals);
    window.AppState.activePanel = activePanel;
  }, [signals, activePanel]);

  useEffect(() => {
    const priceMap: Record<string, { price: number; change24h: number; high24h: number; low24h: number; volume24h: number; spread: number }> = {};
    marketData.forEach(m => {
      priceMap[m.pair] = m;
    });
    syncPricesToGlobal(priceMap);
  }, [marketData]);

  const livePriceGetter = useCallback((pair: string) => getLivePrice(pair), []);

  return (
    <StoreContext.Provider value={{
      activePanel, signals, positions, marketData, guardian, news, sessions,
      isAutoTrade, isTestMode, isLoading, toast,
      setActivePanel, refreshSignals, refreshPositions, refreshMarketData,
      refreshGuardian, toggleAutoTrade, toggleTestMode, executeSignal,
      closePosition, showToast, getLivePrice: livePriceGetter,
    }}>
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}
