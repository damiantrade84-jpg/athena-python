import { useStore } from '@/hooks/useStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  ShieldCheck, CheckCircle, XCircle, AlertTriangle, AlertCircle,
  Zap, TrendingDown, Lock, Unlock, RefreshCw, Activity
} from 'lucide-react';

export default function GuardianPanel() {
  const { guardian, refreshGuardian } = useStore();

  const statusColors = {
    healthy: { bg: 'bg-long/15', text: 'text-long', icon: CheckCircle },
    warning: { bg: 'bg-warning/15', text: 'text-warning', icon: AlertTriangle },
    critical: { bg: 'bg-short/15', text: 'text-short', icon: XCircle },
    unknown: { bg: 'bg-muted', text: 'text-muted-foreground', icon: AlertCircle },
  };

  const sc = statusColors[guardian.overall];
  const StatusIcon = sc.icon;

  const dailyLossPct = Math.min(100, (Math.abs(guardian.dailyLoss) / guardian.dailyLossLimit) * 100);
  const openRiskPct = Math.min(100, (guardian.openRisk / guardian.maxOpenRisk) * 100);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-primary" />
          Guardian — Risk Management
        </h2>
        <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={refreshGuardian}>
          <RefreshCw className="w-3 h-3" />
          Refresh
        </Button>
      </div>

      {/* Overall Health */}
      <Card className={`border-border/60 ${sc.bg}`}>
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-xl ${sc.bg}`}>
              <StatusIcon className={`w-8 h-8 ${sc.text}`} />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Overall System Health</p>
              <p className={`text-2xl font-bold ${sc.text} mt-0.5`}>{guardian.overall.toUpperCase()}</p>
              {guardian.circuitBreaker && (
                <div className="flex items-center gap-1.5 mt-1">
                  <Lock className="w-3.5 h-3.5 text-short" />
                  <span className="text-xs text-short font-medium">Circuit Breaker Active — Trading Halted</span>
                </div>
              )}
              {!guardian.circuitBreaker && (
                <div className="flex items-center gap-1.5 mt-1">
                  <Unlock className="w-3.5 h-3.5 text-long" />
                  <span className="text-xs text-long font-medium">Trading Enabled</span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-3 gap-4">
        {/* Boot Checks */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Activity className="w-4 h-4 text-primary" />
              Boot Checks
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {guardian.bootChecks.map((check, i) => {
                const checkColors = {
                  pass: { icon: CheckCircle, color: 'text-long', bg: 'bg-long/15' },
                  fail: { icon: XCircle, color: 'text-short', bg: 'bg-short/15' },
                  pending: { icon: AlertCircle, color: 'text-warning', bg: 'bg-warning/15' },
                };
                const cc = checkColors[check.status];
                const CheckIcon = cc.icon;
                return (
                  <div key={i} className={`flex items-center gap-2.5 p-2.5 rounded-md ${cc.bg}`}>
                    <CheckIcon className={`w-4 h-4 ${cc.color} shrink-0`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium">{check.name}</p>
                      <p className="text-[10px] text-muted-foreground">{check.message}</p>
                    </div>
                    <Badge className={`text-[9px] ${cc.color} ${cc.bg} border-0`}>
                      {check.status.toUpperCase()}
                    </Badge>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Risk Meters */}
        <div className="space-y-4">
          <Card className="border-border/60 bg-card/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-short" />
                Daily Loss Limit
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Current</span>
                <span className={`text-sm font-mono font-bold ${guardian.dailyLoss < 0 ? 'text-short' : 'text-long'}`}>
                  ${guardian.dailyLoss.toFixed(2)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Limit</span>
                <span className="text-sm font-mono">${guardian.dailyLossLimit}</span>
              </div>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    dailyLossPct > 80 ? 'bg-short' : dailyLossPct > 50 ? 'bg-warning' : 'bg-long'
                  }`}
                  style={{ width: `${dailyLossPct}%` }}
                />
              </div>
              <p className="text-[10px] text-muted-foreground text-right">{dailyLossPct.toFixed(1)}% used</p>
            </CardContent>
          </Card>

          <Card className="border-border/60 bg-card/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <Zap className="w-4 h-4 text-warning" />
                Open Risk
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Current</span>
                <span className="text-sm font-mono font-bold">${guardian.openRisk.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Max</span>
                <span className="text-sm font-mono">${guardian.maxOpenRisk}</span>
              </div>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    openRiskPct > 80 ? 'bg-short' : openRiskPct > 50 ? 'bg-warning' : 'bg-primary'
                  }`}
                  style={{ width: `${openRiskPct}%` }}
                />
              </div>
              <p className="text-[10px] text-muted-foreground text-right">{openRiskPct.toFixed(1)}% used</p>
            </CardContent>
          </Card>

          {guardian.divergence && (
            <div className="p-3 rounded-lg bg-short/10 border border-short/30 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-short shrink-0" />
              <span className="text-xs text-short">Intermarket divergence detected</span>
            </div>
          )}
        </div>

        {/* Circuit Breaker Log */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Lock className="w-4 h-4 text-primary" />
              Circuit Breaker Log
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[320px]">
              <div className="space-y-2">
                {[
                  { time: '08:45:12', event: 'System boot', status: 'pass' },
                  { time: '08:45:15', event: 'API check', status: 'pass' },
                  { time: '08:45:18', event: 'Broker connect', status: 'pass' },
                  { time: '09:12:33', event: 'Daily loss at 45%', status: 'warning' },
                  { time: '09:12:35', event: 'Reduced position sizes', status: 'auto' },
                  { time: '10:30:00', event: 'Risk normalized', status: 'pass' },
                  { time: '11:45:22', event: 'Guardian refresh', status: 'pass' },
                  { time: '12:00:00', event: 'Midday check', status: 'pass' },
                ].map((log, i) => (
                  <div key={i} className="flex items-center gap-2 p-2 rounded-md bg-muted/30">
                    <span className="text-[10px] font-mono text-muted-foreground w-16">{log.time}</span>
                    <span className="text-xs flex-1">{log.event}</span>
                    <Badge variant="outline" className={`text-[9px] ${
                      log.status === 'pass' ? 'border-long/40 text-long' :
                      log.status === 'warning' ? 'border-warning/40 text-warning' :
                      'border-primary/40 text-primary'
                    }`}>
                      {log.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
