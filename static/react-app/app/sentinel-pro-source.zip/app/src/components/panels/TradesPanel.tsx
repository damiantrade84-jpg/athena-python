import { useStore } from '@/hooks/useStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { X } from 'lucide-react';
import { format } from 'date-fns';

export default function TradesPanel() {
  const { positions, closePosition } = useStore();
  const openPositions = positions.filter(p => p.status === 'open');

  const totalPnl = openPositions.reduce((sum, p) => sum + p.pnl, 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div>
            <p className="text-[10px] text-muted-foreground uppercase">Open Positions</p>
            <p className="text-xl font-mono font-bold">{openPositions.length}</p>
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground uppercase">Total P&L</p>
            <p className={`text-xl font-mono font-bold ${totalPnl >= 0 ? 'text-long' : 'text-short'}`}>
              {totalPnl >= 0 ? '+' : ''}${totalPnl.toFixed(2)}
            </p>
          </div>
        </div>
      </div>

      <Card className="border-border/60 bg-card/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Position Manager</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px]">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="text-[10px] uppercase tracking-wider">Pair</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider">Dir</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-right">Entry</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-right">Size</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-right">SL</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-right">TP</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-right">P&L</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-right">P&L%</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider">Broker</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider">Time</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {openPositions.map(p => (
                  <TableRow key={p.id}>
                    <TableCell className="text-xs font-mono font-medium">{p.pair}</TableCell>
                    <TableCell>
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        p.direction === 'LONG' ? 'bg-long/20 text-long' : 'bg-short/20 text-short'
                      }`}>
                        {p.direction}
                      </span>
                    </TableCell>
                    <TableCell className="text-xs font-mono text-right">{p.entry.toFixed(5)}</TableCell>
                    <TableCell className="text-xs font-mono text-right">{p.size.toFixed(2)}</TableCell>
                    <TableCell className="text-xs font-mono text-right text-short">{p.sl.toFixed(5)}</TableCell>
                    <TableCell className="text-xs font-mono text-right text-long">{p.tp.toFixed(5)}</TableCell>
                    <TableCell className={`text-xs font-mono text-right font-bold ${p.pnl >= 0 ? 'text-long' : 'text-short'}`}>
                      {p.pnl >= 0 ? '+' : ''}${p.pnl.toFixed(2)}
                    </TableCell>
                    <TableCell className={`text-xs font-mono text-right ${p.pnlPercent >= 0 ? 'text-long' : 'text-short'}`}>
                      {p.pnlPercent >= 0 ? '+' : ''}{p.pnlPercent.toFixed(2)}%
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-[9px]">{p.broker}</Badge>
                    </TableCell>
                    <TableCell className="text-[10px] font-mono text-muted-foreground">
                      {format(new Date(p.openTime), 'MM/dd HH:mm')}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 w-6 p-0 hover:bg-short/20 hover:text-short"
                        onClick={() => closePosition(p.id)}
                      >
                        <X className="w-3.5 h-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
