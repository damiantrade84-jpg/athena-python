import { useStore } from '@/hooks/useStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell
} from 'recharts';
import {
  TrendingUp, TrendingDown, Activity, Zap, Target,
  Clock, Globe, AlertTriangle, BarChart3,
  Play, Square
} from 'lucide-react';
import { format } from 'date-fns';

export default function DashboardPanel() {
  const { signals, positions, guardian, news, sessions, isAutoTrade, toggleAutoTrade, executeSignal } = useStore();

  const activeSignals = signals.filter(s => s.status === 'active');
  const openPositions = positions.filter(p => p.status === 'open');
  const totalPnl = positions.reduce((sum, p) => sum + p.pnl, 0);

  const equityData = Array.from({ length: 30 }, (_, i) => ({
    day: `D${i + 1}`,
    equity: 10000 + Math.sin(i * 0.3) * 500 + i * 50 + Math.random() * 200,
  }));

  const pnlByPair = positions.slice(0, 6).map(p => ({
    pair: p.pair,
    pnl: p.pnl,
  }));

  return (
    <div className="space-y-5">
      {/* Top Stats Row */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="border-border/60 bg-card/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Total P&L</p>
                <p className={`text-2xl font-mono font-bold mt-1 ${totalPnl >= 0 ? 'text-long' : 'text-short'}`}>
                  {totalPnl >= 0 ? '+' : ''}${totalPnl.toFixed(2)}
                </p>
              </div>
              <div className={`p-2 rounded-lg ${totalPnl >= 0 ? 'bg-long/15' : 'bg-short/15'}`}>
                {totalPnl >= 0 ? <TrendingUp className="w-5 h-5 text-long" /> : <TrendingDown className="w-5 h-5 text-short" />}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-card/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Active Signals</p>
                <p className="text-2xl font-mono font-bold text-primary mt-1">{activeSignals.length}</p>
              </div>
              <div className="p-2 rounded-lg bg-primary/15">
                <Target className="w-5 h-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-card/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Open Positions</p>
                <p className="text-2xl font-mono font-bold text-primary mt-1">{openPositions.length}</p>
              </div>
              <div className="p-2 rounded-lg bg-primary/15">
                <Activity className="w-5 h-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-card/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Guardian Status</p>
                <div className="flex items-center gap-2 mt-1">
                  <p className={`text-lg font-mono font-bold ${
                    guardian.overall === 'healthy' ? 'text-long' :
                    guardian.overall === 'warning' ? 'text-warning' : 'text-short'
                  }`}>
                    {guardian.overall.toUpperCase()}
                  </p>
                  {guardian.circuitBreaker && (
                    <AlertTriangle className="w-4 h-4 text-short animate-pulse" />
                  )}
                </div>
              </div>
              <div className={`p-2 rounded-lg ${
                guardian.overall === 'healthy' ? 'bg-long/15' :
                guardian.overall === 'warning' ? 'bg-warning/15' : 'bg-short/15'
              }`}>
                <Zap className={`w-5 h-5 ${
                  guardian.overall === 'healthy' ? 'text-long' :
                  guardian.overall === 'warning' ? 'text-warning' : 'text-short'
                }`} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-3 gap-5">
        {/* Equity Curve */}
        <Card className="col-span-2 border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" />
                Equity Curve
              </CardTitle>
              <Badge variant="outline" className="text-[10px]">30 Days</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={equityData}>
                  <defs>
                    <linearGradient id="equityGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="day" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} width={50} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px',
                      fontSize: '11px',
                    }}
                    formatter={(value: number) => [`$${value.toFixed(0)}`, 'Equity']}
                  />
                  <Area type="monotone" dataKey="equity" stroke="hsl(var(--primary))" strokeWidth={2} fill="url(#equityGrad)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Session & Controls */}
        <div className="space-y-4">
          <Card className="border-border/60 bg-card/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary" />
                Market Sessions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {sessions.map(s => (
                <div key={s.session} className="flex items-center justify-between p-2 rounded-md bg-muted/30">
                  <div className="flex items-center gap-2">
                    <Globe className={`w-3.5 h-3.5 ${s.active ? 'text-primary' : 'text-muted-foreground'}`} />
                    <span className="text-xs font-medium">{s.session}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-muted-foreground">{s.start}-{s.end}</span>
                    {s.active && (
                      <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-border/60 bg-card/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <Activity className="w-4 h-4 text-primary" />
                Quick Controls
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button
                className="w-full gap-2"
                variant={isAutoTrade ? 'default' : 'outline'}
                size="sm"
                onClick={toggleAutoTrade}
              >
                {isAutoTrade ? <Square className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                {isAutoTrade ? 'Stop Auto-Trade' : 'Start Auto-Trade'}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-3 gap-5">
        {/* Latest Signals */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Target className="w-4 h-4 text-primary" />
              Latest Signals
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[200px]">
              <div className="space-y-2">
                {signals.slice(0, 6).map(signal => (
                  <div key={signal.id} className="flex items-center justify-between p-2 rounded-md bg-muted/30 hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        signal.direction === 'LONG' ? 'bg-long/20 text-long' : 'bg-short/20 text-short'
                      }`}>
                        {signal.direction}
                      </span>
                      <span className="text-xs font-mono font-medium">{signal.pair}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-muted-foreground">{signal.confidence}%</span>
                      <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => executeSignal(signal.id)}>
                        <Play className="w-3 h-3 text-primary" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* P&L by Pair */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-primary" />
              P&L by Pair
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={pnlByPair}>
                  <XAxis dataKey="pair" tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px',
                      fontSize: '11px',
                    }}
                    formatter={(value: number) => [`$${value.toFixed(2)}`, 'P&L']}
                  />
                  <Bar dataKey="pnl" radius={[3, 3, 0, 0]}>
                    {pnlByPair.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.pnl >= 0 ? 'hsl(var(--long))' : 'hsl(var(--short))'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* News Feed */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Globe className="w-4 h-4 text-primary" />
              Market News
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[200px]">
              <div className="space-y-2">
                {news.map(item => (
                  <div key={item.id} className="p-2 rounded-md bg-muted/30">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-xs leading-snug">{item.title}</p>
                      <Badge variant="outline" className={`text-[9px] shrink-0 ${
                        item.impact === 'high' ? 'border-short/40 text-short' :
                        item.impact === 'medium' ? 'border-warning/40 text-warning' :
                        'border-muted-foreground/40 text-muted-foreground'
                      }`}>
                        {item.impact}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] text-muted-foreground">{item.source}</span>
                      <span className="text-[10px] text-muted-foreground">
                        {format(new Date(item.timestamp), 'HH:mm')}
                      </span>
                      <span className={`text-[10px] ${
                        item.sentiment === 'positive' ? 'text-long' :
                        item.sentiment === 'negative' ? 'text-short' :
                        'text-muted-foreground'
                      }`}>
                        {item.sentiment}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
