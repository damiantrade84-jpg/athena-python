import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
} from 'recharts';
import {
  History, Play, TrendingUp, TrendingDown, Target,
  BarChart3, Activity, Shuffle
} from 'lucide-react';
import { generateBacktestResults, PAIRS } from '@/data/mockData';

export default function BacktestPanel() {
  const [results, setResults] = useState(generateBacktestResults());
  const [selectedResult, setSelectedResult] = useState(results[0]);
  const [isRunning, setIsRunning] = useState(false);

  const runBacktest = () => {
    setIsRunning(true);
    setTimeout(() => {
      const newResults = generateBacktestResults();
      setResults(newResults);
      setSelectedResult(newResults[0]);
      setIsRunning(false);
    }, 1500);
  };


  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold flex items-center gap-2">
          <History className="w-4 h-4 text-primary" />
          Backtest Engine
        </h2>
        <div className="flex items-center gap-2">
          <Select defaultValue="all">
            <SelectTrigger className="w-[100px] h-7 text-xs">
              <SelectValue placeholder="Pair" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all" className="text-xs">All Pairs</SelectItem>
              {PAIRS.slice(0, 8).map(p => (
                <SelectItem key={p} value={p} className="text-xs">{p}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            size="sm"
            className="h-7 gap-1 text-xs"
            onClick={runBacktest}
            disabled={isRunning}
          >
            <Play className="w-3 h-3" />
            {isRunning ? 'Running...' : 'Run'}
          </Button>
        </div>
      </div>

      {/* Results Table */}
      <Card className="border-border/60 bg-card/50">
        <CardContent className="p-0">
          <ScrollArea className="h-[200px]">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border/60">
                  <th className="text-left p-3 text-[10px] uppercase tracking-wider text-muted-foreground">Name</th>
                  <th className="text-left p-3 text-[10px] uppercase tracking-wider text-muted-foreground">Pair</th>
                  <th className="text-right p-3 text-[10px] uppercase tracking-wider text-muted-foreground">Return</th>
                  <th className="text-right p-3 text-[10px] uppercase tracking-wider text-muted-foreground">Max DD</th>
                  <th className="text-right p-3 text-[10px] uppercase tracking-wider text-muted-foreground">Sharpe</th>
                  <th className="text-right p-3 text-[10px] uppercase tracking-wider text-muted-foreground">Win %</th>
                  <th className="text-right p-3 text-[10px] uppercase tracking-wider text-muted-foreground">PF</th>
                  <th className="text-right p-3 text-[10px] uppercase tracking-wider text-muted-foreground">Trades</th>
                  <th className="text-right p-3 text-[10px] uppercase tracking-wider text-muted-foreground">SQN</th>
                </tr>
              </thead>
              <tbody>
                {results.map(r => (
                  <tr
                    key={r.id}
                    className={`border-b border-border/30 cursor-pointer transition-colors hover:bg-muted/30 ${
                      selectedResult?.id === r.id ? 'bg-primary/10' : ''
                    }`}
                    onClick={() => setSelectedResult(r)}
                  >
                    <td className="p-3 font-medium">{r.name}</td>
                    <td className="p-3 font-mono">{r.pair}</td>
                    <td className={`p-3 text-right font-mono font-bold ${r.totalReturn >= 0 ? 'text-long' : 'text-short'}`}>
                      {r.totalReturn >= 0 ? '+' : ''}{r.totalReturn.toFixed(2)}%
                    </td>
                    <td className="p-3 text-right font-mono text-short">{r.maxDrawdown.toFixed(2)}%</td>
                    <td className="p-3 text-right font-mono">{r.sharpe.toFixed(2)}</td>
                    <td className="p-3 text-right font-mono">{r.winRate.toFixed(1)}%</td>
                    <td className="p-3 text-right font-mono">{r.profitFactor.toFixed(2)}</td>
                    <td className="p-3 text-right font-mono">{r.trades}</td>
                    <td className="p-3 text-right font-mono">{r.sqn.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Selected Detail */}
      {selectedResult && (
        <div className="grid grid-cols-4 gap-4">
          {/* Equity Curve */}
          <Card className="col-span-3 border-border/60 bg-card/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" />
                Equity Curve — {selectedResult.name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[280px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={selectedResult.equityCurve}>
                    <defs>
                      <linearGradient id="btGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="date" tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} width={50} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '6px',
                        fontSize: '11px',
                      }}
                      formatter={(value: number) => [`$${value.toFixed(0)}`, 'Equity']}
                    />
                    <Area type="monotone" dataKey="equity" stroke="hsl(var(--primary))" strokeWidth={2} fill="url(#btGrad)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Metrics */}
          <div className="space-y-3">
            <Card className="border-border/60 bg-card/50">
              <CardContent className="p-3">
                <div className="flex items-center gap-2 mb-1">
                  <Target className="w-3.5 h-3.5 text-primary" />
                  <span className="text-[10px] text-muted-foreground uppercase">Total Return</span>
                </div>
                <p className={`text-lg font-mono font-bold ${selectedResult.totalReturn >= 0 ? 'text-long' : 'text-short'}`}>
                  {selectedResult.totalReturn >= 0 ? '+' : ''}{selectedResult.totalReturn.toFixed(2)}%
                </p>
              </CardContent>
            </Card>
            <Card className="border-border/60 bg-card/50">
              <CardContent className="p-3">
                <div className="flex items-center gap-2 mb-1">
                  <TrendingDown className="w-3.5 h-3.5 text-short" />
                  <span className="text-[10px] text-muted-foreground uppercase">Max Drawdown</span>
                </div>
                <p className="text-lg font-mono font-bold text-short">{selectedResult.maxDrawdown.toFixed(2)}%</p>
              </CardContent>
            </Card>
            <Card className="border-border/60 bg-card/50">
              <CardContent className="p-3">
                <div className="flex items-center gap-2 mb-1">
                  <BarChart3 className="w-3.5 h-3.5 text-primary" />
                  <span className="text-[10px] text-muted-foreground uppercase">Sharpe Ratio</span>
                </div>
                <p className="text-lg font-mono font-bold">{selectedResult.sharpe.toFixed(2)}</p>
              </CardContent>
            </Card>
            <Card className="border-border/60 bg-card/50">
              <CardContent className="p-3">
                <div className="flex items-center gap-2 mb-1">
                  <Activity className="w-3.5 h-3.5 text-primary" />
                  <span className="text-[10px] text-muted-foreground uppercase">Profit Factor</span>
                </div>
                <p className="text-lg font-mono font-bold">{selectedResult.profitFactor.toFixed(2)}</p>
              </CardContent>
            </Card>
            <Card className="border-border/60 bg-card/50">
              <CardContent className="p-3">
                <div className="flex items-center gap-2 mb-1">
                  <Shuffle className="w-3.5 h-3.5 text-primary" />
                  <span className="text-[10px] text-muted-foreground uppercase">SQN</span>
                </div>
                <p className="text-lg font-mono font-bold">{selectedResult.sqn.toFixed(2)}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
