import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  FlaskConical, Send, Bot, User, BrainCircuit, Sparkles,
  TrendingUp, AlertTriangle, Lightbulb
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

const initialMessages: ChatMessage[] = [
  {
    id: '1',
    role: 'assistant',
    content: 'Welcome to the Research Lab. I\'m VectorBT, your quantitative research assistant. I can help you analyze strategies, run statistical tests, and optimize parameters. What would you like to research today?',
    timestamp: '10:00:00',
  },
];

const sampleResponses = [
  "Based on the backtest data, your strategy shows a Sharpe ratio of 1.85 with a maximum drawdown of 8.2%. The equity curve indicates consistent performance across market regimes. I recommend testing with walk-forward validation to confirm robustness.",
  "The Monte Carlo analysis reveals a 95% confidence interval for maximum drawdown between 6.8% and 12.4%. Your SQN of 2.3 suggests a good system with reliable edge.",
  "I've analyzed the correlation matrix. Your EURUSD and GBPUSD positions show 0.78 correlation — consider reducing position sizes to avoid concentration risk. Diversifying into uncorrelated pairs like USDJPY could improve risk-adjusted returns.",
  "The parameter sensitivity analysis indicates your strategy is robust across a wide range of values. The optimal lookback period is 14-21 periods, with diminishing returns beyond 25.",
];

export default function ResearchLabPanel() {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [input, setInput] = useState('');
  const [isThinking, setIsThinking] = useState(false);

  const sendMessage = () => {
    if (!input.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsThinking(true);

    setTimeout(() => {
      const response: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: sampleResponses[Math.floor(Math.random() * sampleResponses.length)],
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
      };
      setMessages(prev => [...prev, response]);
      setIsThinking(false);
    }, 1200);
  };

  return (
    <div className="grid grid-cols-4 gap-4 h-[calc(100vh-120px)]">
      {/* Chat */}
      <Card className="col-span-3 border-border/60 bg-card/50 flex flex-col">
        <CardHeader className="pb-2 shrink-0">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <FlaskConical className="w-4 h-4 text-primary" />
            Research Assistant
            <Badge variant="outline" className="text-[9px] ml-2">VectorBT</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col min-h-0">
          <ScrollArea className="flex-1 pr-2">
            <div className="space-y-4">
              {messages.map(msg => (
                <div key={msg.id} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                  {msg.role === 'assistant' && (
                    <div className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                      <BrainCircuit className="w-3.5 h-3.5 text-primary" />
                    </div>
                  )}
                  <div className={`max-w-[80%] p-3 rounded-lg ${
                    msg.role === 'user'
                      ? 'bg-primary/20 border border-primary/30'
                      : 'bg-muted/40 border border-border/40'
                  }`}>
                    <p className="text-xs leading-relaxed">{msg.content}</p>
                    <span className="text-[9px] text-muted-foreground mt-1 block">{msg.timestamp}</span>
                  </div>
                  {msg.role === 'user' && (
                    <div className="w-7 h-7 rounded-lg bg-muted flex items-center justify-center shrink-0 mt-0.5">
                      <User className="w-3.5 h-3.5" />
                    </div>
                  )}
                </div>
              ))}
              {isThinking && (
                <div className="flex gap-3">
                  <div className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center shrink-0">
                    <Sparkles className="w-3.5 h-3.5 text-primary animate-pulse" />
                  </div>
                  <div className="p-3 rounded-lg bg-muted/40 border border-border/40">
                    <div className="flex items-center gap-1.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
                      <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
                      <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="mt-3 flex gap-2 shrink-0">
            <Textarea
              placeholder="Ask about backtests, strategy analysis, parameter optimization..."
              className="min-h-[60px] text-xs resize-none"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
            />
            <Button className="h-auto px-3" onClick={sendMessage} disabled={isThinking}>
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tools Sidebar */}
      <div className="space-y-3">
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Quick Analysis</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {[
              { icon: TrendingUp, label: 'Sharpe Analysis', desc: 'Calculate risk-adjusted returns' },
              { icon: AlertTriangle, label: 'Drawdown Study', desc: 'Analyze worst-case scenarios' },
              { icon: Lightbulb, label: 'Parameter Sweep', desc: 'Find optimal settings' },
              { icon: Bot, label: 'Monte Carlo', desc: 'Run 10K simulations' },
            ].map(tool => (
              <button
                key={tool.label}
                className="w-full flex items-center gap-2.5 p-2.5 rounded-md hover:bg-muted/40 transition-colors text-left"
                onClick={() => {
                  setInput(`Run ${tool.label.toLowerCase()} on my strategy`);
                }}
              >
                <div className="w-8 h-8 rounded-md bg-primary/15 flex items-center justify-center shrink-0">
                  <tool.icon className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs font-medium">{tool.label}</p>
                  <p className="text-[10px] text-muted-foreground">{tool.desc}</p>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Research Notes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="p-2 rounded-md bg-muted/30 text-[10px] text-muted-foreground">
                Strategy A shows best performance during London session
              </div>
              <div className="p-2 rounded-md bg-muted/30 text-[10px] text-muted-foreground">
                Engine C consensus filter reduces false signals by 34%
              </div>
              <div className="p-2 rounded-md bg-muted/30 text-[10px] text-muted-foreground">
                Gold (XAUUSD) responds well to FVG setups on M15
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
