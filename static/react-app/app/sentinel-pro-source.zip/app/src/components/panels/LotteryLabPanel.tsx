import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { generateLotteryNumbers, generateLotteryAnalysis } from '@/data/mockData';
import { Dices, Flame, Snowflake, Clock, RefreshCw, Sparkles } from 'lucide-react';

export default function LotteryLabPanel() {
  const [numbers, setNumbers] = useState(generateLotteryNumbers);
  const [analysis] = useState(generateLotteryAnalysis);
  const [generatedSet, setGeneratedSet] = useState<number[]>([]);

  const generateSet = () => {
    const nums = new Set<number>();
    while (nums.size < 5) nums.add(Math.floor(Math.random() * 69) + 1);
    setGeneratedSet(Array.from(nums).sort((a, b) => a - b));
  };

  const refreshNumbers = () => setNumbers(generateLotteryNumbers);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold flex items-center gap-2">
          <Dices className="w-4 h-4 text-primary" />
          Lottery Lab
        </h2>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={refreshNumbers}>
            <RefreshCw className="w-3 h-3" />
            Refresh
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Hot Numbers */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Flame className="w-4 h-4 text-orange-400" />
              Hot Numbers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {analysis.hotNumbers.map(h => (
                <div key={h.number} className="flex items-center justify-between p-2 rounded-md bg-muted/30">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-orange-500/20 flex items-center justify-center">
                      <span className="text-sm font-mono font-bold text-orange-400">{h.number}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">{h.frequency} draws</span>
                  </div>
                  <div className="w-20 h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-orange-400 rounded-full" style={{ width: `${(h.frequency / 45) * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Cold Numbers */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Snowflake className="w-4 h-4 text-cyan-400" />
              Cold Numbers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {analysis.coldNumbers.map(c => (
                <div key={c.number} className="flex items-center justify-between p-2 rounded-md bg-muted/30">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center">
                      <span className="text-sm font-mono font-bold text-cyan-400">{c.number}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">{c.frequency} draws</span>
                  </div>
                  <div className="w-20 h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-cyan-400 rounded-full" style={{ width: `${(c.frequency / 10) * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Generator */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" />
              Quick Pick Generator
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {generatedSet.length > 0 && (
              <div className="flex items-center justify-center gap-2 py-3">
                {generatedSet.map(n => (
                  <div key={n} className="w-10 h-10 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center">
                    <span className="text-sm font-mono font-bold text-primary">{n}</span>
                  </div>
                ))}
              </div>
            )}
            <Button className="w-full gap-2" onClick={generateSet}>
              <Sparkles className="w-4 h-4" />
              Generate Numbers
            </Button>

            <div className="pt-3 border-t border-border/40 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Odd/Even Ratio</span>
                <span className="text-xs font-mono">{(analysis.oddEvenRatio.odd * 100).toFixed(0)}% / {(analysis.oddEvenRatio.even * 100).toFixed(0)}%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Avg Sum</span>
                <span className="text-xs font-mono">{analysis.sumStats.avg}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Sum Range</span>
                <span className="text-xs font-mono">{analysis.sumStats.min} - {analysis.sumStats.max}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Draws */}
      <Card className="border-border/60 bg-card/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Clock className="w-4 h-4 text-primary" />
            Recent Draw History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[200px]">
            <div className="space-y-2">
              {numbers.slice(0, 15).map((n, i) => (
                <div key={i} className="flex items-center justify-between p-2 rounded-md bg-muted/30">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[9px]">{n.game}</Badge>
                    <span className="text-[10px] text-muted-foreground">{n.date}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {n.numbers.map(num => (
                      <div key={num} className="w-6 h-6 rounded-full bg-muted flex items-center justify-center">
                        <span className="text-[10px] font-mono font-bold">{num}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
