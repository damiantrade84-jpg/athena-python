import { useEffect, useRef, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PAIRS } from '@/data/mockData';
import { LineChart, Maximize2 } from 'lucide-react';

export default function TVChartPanel() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [pair, setPair] = useState('EURUSD');
  const [timeframe, setTimeframe] = useState('60');

  useEffect(() => {
    if (!containerRef.current) return;
    containerRef.current.innerHTML = '';

    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js';
    script.type = 'text/javascript';
    script.async = true;
    script.innerHTML = JSON.stringify({
      autosize: true,
      symbol: `FX:${pair}`,
      interval: timeframe,
      timezone: 'Etc/UTC',
      theme: 'dark',
      style: '1',
      locale: 'en',
      enable_publishing: false,
      backgroundColor: 'rgba(10, 10, 15, 1)',
      gridColor: 'rgba(38, 38, 55, 0.3)',
      hide_top_toolbar: false,
      hide_legend: false,
      withdateranges: true,
      hide_side_toolbar: false,
      allow_symbol_change: false,
      details: true,
      hotlist: false,
      calendar: false,
      studies: ['MASimple@tv-basicstudies', 'RSI@tv-basicstudies'],
      show_popup_button: true,
      popup_width: '1000',
      popup_height: '650',
    });

    const widgetContainer = document.createElement('div');
    widgetContainer.className = 'tradingview-widget-container';
    widgetContainer.style.height = '100%';

    const widget = document.createElement('div');
    widget.className = 'tradingview-widget-container__widget';
    widget.style.height = '100%';

    widgetContainer.appendChild(widget);
    widgetContainer.appendChild(script);
    containerRef.current.appendChild(widgetContainer);

    return () => {
      if (containerRef.current) {
        containerRef.current.innerHTML = '';
      }
    };
  }, [pair, timeframe]);

  return (
    <div className="space-y-4 h-full">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold flex items-center gap-2">
          <LineChart className="w-4 h-4 text-primary" />
          TradingView Chart
        </h2>
        <div className="flex items-center gap-2">
          <Select value={pair} onValueChange={setPair}>
            <SelectTrigger className="w-[120px] h-7 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {PAIRS.slice(0, 10).map(p => (
                <SelectItem key={p} value={p} className="text-xs">{p}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-[80px] h-7 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1" className="text-xs">1m</SelectItem>
              <SelectItem value="5" className="text-xs">5m</SelectItem>
              <SelectItem value="15" className="text-xs">15m</SelectItem>
              <SelectItem value="60" className="text-xs">1H</SelectItem>
              <SelectItem value="240" className="text-xs">4H</SelectItem>
              <SelectItem value="D" className="text-xs">1D</SelectItem>
            </SelectContent>
          </Select>
          <Button size="sm" variant="outline" className="h-7 w-7 p-0">
            <Maximize2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      <Card className="border-border/60 bg-card/50 h-[calc(100vh-160px)]">
        <CardContent className="p-0 h-full">
          <div ref={containerRef} className="w-full h-full rounded-lg overflow-hidden" />
        </CardContent>
      </Card>
    </div>
  );
}
