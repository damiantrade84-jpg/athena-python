import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { generateScreenerResults } from '@/data/mockData';
import { Filter, TrendingUp, TrendingDown, Minus } from 'lucide-react';

export default function ScreenerPanel() {
  const [results] = useState(generateScreenerResults());
  const [filter, setFilter] = useState('');

  const filtered = results.filter(r =>
    !filter || r.pair.toLowerCase().includes(filter.toLowerCase())
  );

  const trendColor = (trend: string) => {
    switch (trend) {
      case 'bullish': return 'text-long';
      case 'bearish': return 'text-short';
      default: return 'text-muted-foreground';
    }
  };

  const trendIcon = (trend: string) => {
    switch (trend) {
      case 'bullish': return <TrendingUp className="w-3.5 h-3.5 text-long" />;
      case 'bearish': return <TrendingDown className="w-3.5 h-3.5 text-short" />;
      default: return <Minus className="w-3.5 h-3.5 text-muted-foreground" />;
    }
  };

  const sentimentColor = (s: string) => {
    switch (s) {
      case 'risk_on': return 'bg-long/20 text-long';
      case 'risk_off': return 'bg-short/20 text-short';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold flex items-center gap-2">
          <Filter className="w-4 h-4 text-primary" />
          Market Screener
        </h2>
        <div className="relative w-56">
          <Filter className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            placeholder="Filter pairs..."
            className="pl-8 h-8 text-xs"
            value={filter}
            onChange={e => setFilter(e.target.value)}
          />
        </div>
      </div>

      <Card className="border-border/60 bg-card/50">
        <CardContent className="p-0">
          <ScrollArea className="h-[620px]">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border/60">
                  <th className="text-left p-3 text-[10px] uppercase tracking-wider text-muted-foreground">Pair</th>
                  <th className="text-left p-3 text-[10px] uppercase tracking-wider text-muted-foreground">Trend</th>
                  <th className="text-right p-3 text-[10px] uppercase tracking-wider text-muted-foreground">Strength</th>
                  <th className="text-right p-3 text-[10px] uppercase tracking-wider text-muted-foreground">RSI</th>
                  <th className="text-right p-3 text-[10px] uppercase tracking-wider text-muted-foreground">MACD</th>
                  <th className="text-right p-3 text-[10px] uppercase tracking-wider text-muted-foreground">Volume</th>
                  <th className="text-right p-3 text-[10px] uppercase tracking-wider text-muted-foreground">ATR</th>
                  <th className="text-left p-3 text-[10px] uppercase tracking-wider text-muted-foreground">Sentiment</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(r => (
                  <tr key={r.pair} className="border-b border-border/30 hover:bg-muted/30 transition-colors">
                    <td className="p-3">
                      <span className="font-mono font-medium">{r.pair}</span>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-1.5">
                        {trendIcon(r.trend)}
                        <span className={`font-medium ${trendColor(r.trend)}`}>
                          {r.trend.charAt(0).toUpperCase() + r.trend.slice(1)}
                        </span>
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-2 justify-end">
                        <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              r.trend === 'bullish' ? 'bg-long' : r.trend === 'bearish' ? 'bg-short' : 'bg-muted-foreground'
                            }`}
                            style={{ width: `${r.strength}%` }}
                          />
                        </div>
                        <span className="font-mono">{r.strength.toFixed(0)}%</span>
                      </div>
                    </td>
                    <td className="p-3 text-right font-mono">
                      <span className={r.rsi > 70 ? 'text-short' : r.rsi < 30 ? 'text-long' : ''}>
                        {r.rsi.toFixed(1)}
                      </span>
                    </td>
                    <td className="p-3 text-right font-mono">
                      <span className={r.macd > 0 ? 'text-long' : 'text-short'}>
                        {r.macd > 0 ? '+' : ''}{r.macd.toFixed(3)}
                      </span>
                    </td>
                    <td className="p-3 text-right font-mono">{(r.volume / 1000).toFixed(1)}K</td>
                    <td className="p-3 text-right font-mono">{r.atr.toFixed(5)}</td>
                    <td className="p-3">
                      <Badge className={`text-[9px] ${sentimentColor(r.sentiment)}`}>
                        {r.sentiment.replace('_', ' ')}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
