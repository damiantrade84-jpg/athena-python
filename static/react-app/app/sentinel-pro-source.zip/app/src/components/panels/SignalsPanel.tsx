import { useState } from 'react';
import { useStore } from '@/hooks/useStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Search, Play, Eye, ArrowUpRight, RefreshCw } from 'lucide-react';
import { format } from 'date-fns';

export default function SignalsPanel() {
  const { signals, executeSignal, refreshSignals } = useStore();
  const [filter, setFilter] = useState('');
  const [directionFilter, setDirectionFilter] = useState<string>('all');
  const [engineFilter, setEngineFilter] = useState<string>('all');
  const [selectedSignal, setSelectedSignal] = useState<string | null>(null);

  const signal = signals.find(s => s.id === selectedSignal);

  const filtered = signals.filter(s => {
    if (filter && !s.pair.toLowerCase().includes(filter.toLowerCase())) return false;
    if (directionFilter !== 'all' && s.direction !== directionFilter) return false;
    if (engineFilter !== 'all' && !s.engine.includes(engineFilter)) return false;
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            placeholder="Filter by pair..."
            className="pl-8 h-8 text-xs"
            value={filter}
            onChange={e => setFilter(e.target.value)}
          />
        </div>
        <Select value={directionFilter} onValueChange={setDirectionFilter}>
          <SelectTrigger className="w-[120px] h-8 text-xs">
            <SelectValue placeholder="Direction" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="LONG">Long</SelectItem>
            <SelectItem value="SHORT">Short</SelectItem>
          </SelectContent>
        </Select>
        <Select value={engineFilter} onValueChange={setEngineFilter}>
          <SelectTrigger className="w-[140px] h-8 text-xs">
            <SelectValue placeholder="Engine" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Engines</SelectItem>
            <SelectItem value="A">Engine A</SelectItem>
            <SelectItem value="B">Engine B</SelectItem>
            <SelectItem value="C">Engine C</SelectItem>
            <SelectItem value="D">Engine D</SelectItem>
          </SelectContent>
        </Select>
        <Button size="sm" variant="outline" className="h-8 gap-1 text-xs" onClick={refreshSignals}>
          <RefreshCw className="w-3 h-3" />
          Refresh
        </Button>
      </div>

      <div className="grid grid-cols-5 gap-4">
        {/* Signal Table */}
        <Card className="col-span-3 border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center justify-between">
              <span>Signal Feed</span>
              <Badge variant="outline" className="text-[10px]">{filtered.length} signals</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[540px]">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-[10px] uppercase tracking-wider">Pair</TableHead>
                    <TableHead className="text-[10px] uppercase tracking-wider">Dir</TableHead>
                    <TableHead className="text-[10px] uppercase tracking-wider text-right">Entry</TableHead>
                    <TableHead className="text-[10px] uppercase tracking-wider text-right">SL</TableHead>
                    <TableHead className="text-[10px] uppercase tracking-wider text-right">TP</TableHead>
                    <TableHead className="text-[10px] uppercase tracking-wider">Conf</TableHead>
                    <TableHead className="text-[10px] uppercase tracking-wider">Engine</TableHead>
                    <TableHead className="text-[10px] uppercase tracking-wider">Time</TableHead>
                    <TableHead className="text-[10px] uppercase tracking-wider text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map(s => (
                    <TableRow
                      key={s.id}
                      className={`cursor-pointer transition-colors ${selectedSignal === s.id ? 'bg-primary/10' : ''}`}
                      onClick={() => setSelectedSignal(s.id)}
                    >
                      <TableCell className="text-xs font-mono font-medium">{s.pair}</TableCell>
                      <TableCell>
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                          s.direction === 'LONG' ? 'bg-long/20 text-long' : 'bg-short/20 text-short'
                        }`}>
                          {s.direction}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs font-mono text-right">{s.entry.toFixed(5)}</TableCell>
                      <TableCell className="text-xs font-mono text-right text-short">{s.sl.toFixed(5)}</TableCell>
                      <TableCell className="text-xs font-mono text-right text-long">{s.tp.toFixed(5)}</TableCell>
                      <TableCell>
                        <span className={`text-xs font-mono font-bold ${
                          s.confidence >= 85 ? 'text-long' : s.confidence >= 70 ? 'text-warning' : 'text-muted-foreground'
                        }`}>
                          {s.confidence}%
                        </span>
                      </TableCell>
                      <TableCell className="text-[10px] text-muted-foreground">{s.engine}</TableCell>
                      <TableCell className="text-[10px] font-mono text-muted-foreground">
                        {format(new Date(s.timestamp), 'HH:mm:ss')}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0"
                          onClick={e => { e.stopPropagation(); executeSignal(s.id); }}
                        >
                          <Play className="w-3 h-3 text-primary" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Signal Detail */}
        <Card className="col-span-2 border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Signal Detail</CardTitle>
          </CardHeader>
          <CardContent>
            {signal ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-lg font-mono font-bold">{signal.pair}</span>
                    <span className={`text-xs font-bold px-2 py-1 rounded ${
                      signal.direction === 'LONG' ? 'bg-long/20 text-long' : 'bg-short/20 text-short'
                    }`}>
                      {signal.direction}
                    </span>
                  </div>
                  <Badge variant="outline" className="text-[10px]">{signal.engine}</Badge>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-muted/30">
                    <p className="text-[10px] text-muted-foreground uppercase">Entry Price</p>
                    <p className="text-sm font-mono font-bold mt-0.5">{signal.entry.toFixed(5)}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/30">
                    <p className="text-[10px] text-muted-foreground uppercase">Confidence</p>
                    <p className="text-sm font-mono font-bold mt-0.5 text-primary">{signal.confidence}%</p>
                  </div>
                  <div className="p-3 rounded-lg bg-short/10 border border-short/20">
                    <p className="text-[10px] text-short uppercase">Stop Loss</p>
                    <p className="text-sm font-mono font-bold mt-0.5 text-short">{signal.sl.toFixed(5)}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      Risk: {((Math.abs(signal.entry - signal.sl) / signal.entry) * 100).toFixed(2)}%
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-long/10 border border-long/20">
                    <p className="text-[10px] text-long uppercase">Take Profit</p>
                    <p className="text-sm font-mono font-bold mt-0.5 text-long">{signal.tp.toFixed(5)}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      R:R {signal.rRatio.toFixed(2)}
                    </p>
                  </div>
                </div>

                {signal.tp2 && (
                  <div className="flex items-center gap-2 p-2 rounded-lg bg-long/5">
                    <ArrowUpRight className="w-3.5 h-3.5 text-long" />
                    <span className="text-xs text-muted-foreground">TP2: </span>
                    <span className="text-xs font-mono font-medium">{signal.tp2.toFixed(5)}</span>
                  </div>
                )}
                {signal.tp3 && (
                  <div className="flex items-center gap-2 p-2 rounded-lg bg-long/5">
                    <ArrowUpRight className="w-3.5 h-3.5 text-long" />
                    <span className="text-xs text-muted-foreground">TP3: </span>
                    <span className="text-xs font-mono font-medium">{signal.tp3.toFixed(5)}</span>
                  </div>
                )}

                {signal.factors && signal.factors.length > 0 && (
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase mb-2">Confluence Factors</p>
                    <div className="flex flex-wrap gap-1.5">
                      {signal.factors.map(f => (
                        <Badge key={f} variant="secondary" className="text-[10px]">{f}</Badge>
                      ))}
                    </div>
                  </div>
                )}

                {signal.notes && (
                  <div className="p-3 rounded-lg bg-muted/30">
                    <p className="text-[10px] text-muted-foreground uppercase mb-1">Notes</p>
                    <p className="text-xs">{signal.notes}</p>
                  </div>
                )}

                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span>Timeframe: {signal.timeframe}</span>
                  <span>Votes: {signal.votes}/10</span>
                </div>

                <Button className="w-full gap-2" onClick={() => executeSignal(signal.id)}>
                  <Play className="w-4 h-4" />
                  Execute Signal
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-[400px] text-muted-foreground">
                <Eye className="w-8 h-8 mb-3 opacity-40" />
                <p className="text-sm">Select a signal to view details</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
