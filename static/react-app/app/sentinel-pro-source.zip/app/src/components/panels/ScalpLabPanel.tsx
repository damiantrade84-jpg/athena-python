import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Timer, Zap, Crosshair, TrendingUp, TrendingDown,
  Activity, Gauge, Play
} from 'lucide-react';

const scalpSetups = [
  {
    id: '1', pair: 'EURUSD', direction: 'LONG' as const, confidence: 82,
    entry: 1.08450, sl: 1.08420, tp: 1.08510, tp2: 1.08550,
    timeframe: 'M1', setup: 'FVG + Liquidity Sweep',
    factors: ['Fair Value Gap', 'Order Block', 'Liquidity Grab', 'Volume Imbalance'],
  },
  {
    id: '2', pair: 'GBPUSD', direction: 'SHORT' as const, confidence: 76,
    entry: 1.26800, sl: 1.26840, tp: 1.26720, tp2: 1.26680,
    timeframe: 'M5', setup: 'Breaker Block + Displacement',
    factors: ['Breaker Block', 'Displacement', 'Premium Array', 'ICT OTE'],
  },
  {
    id: '3', pair: 'XAUUSD', direction: 'LONG' as const, confidence: 91,
    entry: 2385.50, sl: 2384.80, tp: 2387.00, tp2: 2388.50,
    timeframe: 'M1', setup: 'Order Block + FVG',
    factors: ['Bullish Order Block', 'FVG Fill', 'Asian Range Liquidity', 'SL Hunt'],
  },
  {
    id: '4', pair: 'USDJPY', direction: 'SHORT' as const, confidence: 73,
    entry: 151.850, sl: 151.920, tp: 151.720, tp2: 151.650,
    timeframe: 'M5', setup: ' inducement + MSS',
    factors: ['Market Structure Shift', 'Inducement', 'OTE Short', 'Volume Spike'],
  },
];

export default function ScalpLabPanel() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold flex items-center gap-2">
          <Timer className="w-4 h-4 text-primary" />
          Scalp Lab — Engine D
        </h2>
        <Badge variant="outline" className="text-[10px]">Fabio Valentini VP+ OrderFlow</Badge>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3">
        <Card className="border-border/60 bg-card/50">
          <CardContent className="p-3 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/15">
              <Crosshair className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase">Active Setups</p>
              <p className="text-lg font-mono font-bold">{scalpSetups.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60 bg-card/50">
          <CardContent className="p-3 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-long/15">
              <TrendingUp className="w-4 h-4 text-long" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase">Long</p>
              <p className="text-lg font-mono font-bold text-long">{scalpSetups.filter(s => s.direction === 'LONG').length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60 bg-card/50">
          <CardContent className="p-3 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-short/15">
              <TrendingDown className="w-4 h-4 text-short" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase">Short</p>
              <p className="text-lg font-mono font-bold text-short">{scalpSetups.filter(s => s.direction === 'SHORT').length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60 bg-card/50">
          <CardContent className="p-3 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-warning/15">
              <Gauge className="w-4 h-4 text-warning" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase">Avg Confidence</p>
              <p className="text-lg font-mono font-bold">{(scalpSetups.reduce((s, x) => s + x.confidence, 0) / scalpSetups.length).toFixed(0)}%</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Setups */}
      <div className="grid grid-cols-2 gap-4">
        {scalpSetups.map(setup => (
          <Card key={setup.id} className="border-border/60 bg-card/50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-mono font-bold">{setup.pair}</span>
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    setup.direction === 'LONG' ? 'bg-long/20 text-long' : 'bg-short/20 text-short'
                  }`}>
                    {setup.direction}
                  </span>
                  <Badge variant="outline" className="text-[9px] font-mono">{setup.timeframe}</Badge>
                </div>
                <Badge className={`text-[9px] ${setup.confidence >= 85 ? 'bg-long/20 text-long' : 'bg-warning/20 text-warning'}`}>
                  {setup.confidence}%
                </Badge>
              </div>

              <p className="text-xs text-muted-foreground mb-3 flex items-center gap-1.5">
                <Zap className="w-3 h-3 text-primary" />
                {setup.setup}
              </p>

              <div className="grid grid-cols-3 gap-2 mb-3">
                <div className="p-2 rounded bg-muted/30 text-center">
                  <p className="text-[9px] text-muted-foreground">Entry</p>
                  <p className="text-xs font-mono font-bold">{setup.entry.toFixed(5)}</p>
                </div>
                <div className="p-2 rounded bg-short/10 text-center">
                  <p className="text-[9px] text-short">SL</p>
                  <p className="text-xs font-mono font-bold text-short">{setup.sl.toFixed(5)}</p>
                </div>
                <div className="p-2 rounded bg-long/10 text-center">
                  <p className="text-[9px] text-long">TP</p>
                  <p className="text-xs font-mono font-bold text-long">{setup.tp.toFixed(5)}</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-1 mb-3">
                {setup.factors.map(f => (
                  <Badge key={f} variant="secondary" className="text-[9px]">{f}</Badge>
                ))}
              </div>

              <Button size="sm" className="w-full gap-1 text-xs">
                <Play className="w-3 h-3" />
                Execute Scalp
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* VP+ Info */}
      <Card className="border-border/60 bg-card/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Activity className="w-4 h-4 text-primary" />
            Volume Profile + OrderFlow Methodology
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-3">
            {[
              { label: 'Point of Control', value: '2,387.45', desc: 'Highest volume node' },
              { label: 'Value Area High', value: '2,390.12', desc: 'Upper VA boundary' },
              { label: 'Value Area Low', value: '2,384.80', desc: 'Lower VA boundary' },
              { label: 'VWAP', value: '2,386.90', desc: 'Volume-weighted price' },
            ].map(item => (
              <div key={item.label} className="p-3 rounded-lg bg-muted/30">
                <p className="text-[10px] text-muted-foreground">{item.label}</p>
                <p className="text-sm font-mono font-bold mt-0.5">{item.value}</p>
                <p className="text-[9px] text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
