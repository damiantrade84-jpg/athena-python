import { useStore } from '@/hooks/useStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  GitMerge, CheckCircle, AlertCircle,
  TrendingUp, Shield, Brain
} from 'lucide-react';

export default function EngineCPanel() {
  const { signals } = useStore();

  const consensusSignals = signals.filter(s => s.engine?.includes('C') || (s.votes && s.votes >= 7));

  const metrics = {
    total: consensusSignals.length,
    long: consensusSignals.filter(s => s.direction === 'LONG').length,
    short: consensusSignals.filter(s => s.direction === 'SHORT').length,
    highConviction: consensusSignals.filter(s => (s.confidence || 0) >= 85).length,
    avgConfidence: consensusSignals.length > 0
      ? consensusSignals.reduce((sum, s) => sum + (s.confidence || 0), 0) / consensusSignals.length
      : 0,
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold flex items-center gap-2">
          <GitMerge className="w-4 h-4 text-primary" />
          Engine C — Consensus Model
        </h2>
        <Badge variant="outline" className="text-[10px]">A + B Blended</Badge>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-5 gap-3">
        <Card className="border-border/60 bg-card/50">
          <CardContent className="p-3">
            <p className="text-[10px] text-muted-foreground uppercase">Consensus Signals</p>
            <p className="text-xl font-mono font-bold">{metrics.total}</p>
          </CardContent>
        </Card>
        <Card className="border-border/60 bg-card/50">
          <CardContent className="p-3">
            <p className="text-[10px] text-muted-foreground uppercase">Long Bias</p>
            <p className="text-xl font-mono font-bold text-long">{metrics.long}</p>
          </CardContent>
        </Card>
        <Card className="border-border/60 bg-card/50">
          <CardContent className="p-3">
            <p className="text-[10px] text-muted-foreground uppercase">Short Bias</p>
            <p className="text-xl font-mono font-bold text-short">{metrics.short}</p>
          </CardContent>
        </Card>
        <Card className="border-border/60 bg-card/50">
          <CardContent className="p-3">
            <p className="text-[10px] text-muted-foreground uppercase">High Conviction</p>
            <p className="text-xl font-mono font-bold text-primary">{metrics.highConviction}</p>
          </CardContent>
        </Card>
        <Card className="border-border/60 bg-card/50">
          <CardContent className="p-3">
            <p className="text-[10px] text-muted-foreground uppercase">Avg Confidence</p>
            <p className="text-xl font-mono font-bold">{metrics.avgConfidence.toFixed(1)}%</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Consensus Signals */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Brain className="w-4 h-4 text-primary" />
              Blended Signals
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px]">
              <div className="space-y-2">
                {consensusSignals.map(s => (
                  <div key={s.id} className="p-3 rounded-lg bg-muted/30 border border-border/40">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-mono font-bold">{s.pair}</span>
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                          s.direction === 'LONG' ? 'bg-long/20 text-long' : 'bg-short/20 text-short'
                        }`}>
                          {s.direction}
                        </span>
                      </div>
                      <Badge variant="outline" className="text-[9px]">{s.confidence}%</Badge>
                    </div>
                    <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                      <span>Entry: {s.entry.toFixed(5)}</span>
                      <span>SL: {s.sl.toFixed(5)}</span>
                      <span>TP: {s.tp.toFixed(5)}</span>
                      <span>R:R {s.rRatio?.toFixed(2)}</span>
                    </div>
                    {s.votes && (
                      <div className="mt-2 flex items-center gap-1">
                        {Array.from({ length: 10 }, (_, i) => (
                          <div
                            key={i}
                            className={`h-1 flex-1 rounded-full ${
                              i < s.votes! ? 'bg-primary' : 'bg-muted-foreground/20'
                            }`}
                          />
                        ))}
                        <span className="text-[9px] font-mono ml-1">{s.votes}/10</span>
                      </div>
                    )}
                  </div>
                ))}
                {consensusSignals.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-8">No consensus signals</p>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Conviction Gating */}
        <div className="space-y-4">
          <Card className="border-border/60 bg-card/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <Shield className="w-4 h-4 text-primary" />
                Conviction Gating
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between p-2 rounded-md bg-long/10 border border-long/20">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-long" />
                  <span className="text-xs">Engine A Agrees</span>
                </div>
                <Badge className="bg-long/20 text-long text-[9px]">PASS</Badge>
              </div>
              <div className="flex items-center justify-between p-2 rounded-md bg-long/10 border border-long/20">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-long" />
                  <span className="text-xs">Engine B Confirms</span>
                </div>
                <Badge className="bg-long/20 text-long text-[9px]">PASS</Badge>
              </div>
              <div className="flex items-center justify-between p-2 rounded-md bg-long/10 border border-long/20">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-long" />
                  <span className="text-xs">Minimum 7/10 Votes</span>
                </div>
                <Badge className="bg-long/20 text-long text-[9px]">PASS</Badge>
              </div>
              <div className="flex items-center justify-between p-2 rounded-md bg-long/10 border border-long/20">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-long" />
                  <span className="text-xs">Risk Threshold OK</span>
                </div>
                <Badge className="bg-long/20 text-long text-[9px]">PASS</Badge>
              </div>
              <div className="flex items-center justify-between p-2 rounded-md bg-warning/10 border border-warning/20">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-warning" />
                  <span className="text-xs">News Sentiment</span>
                </div>
                <Badge className="bg-warning/20 text-warning text-[9px]">NEUTRAL</Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/60 bg-card/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" />
                Blending Weights
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span>Engine A (Quant)</span>
                  <span className="font-mono">40%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-primary/70 h-2 rounded-full" style={{ width: '40%' }} />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span>Engine B (Structure)</span>
                  <span className="font-mono">40%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-primary/70 h-2 rounded-full" style={{ width: '40%' }} />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span>Conviction Gating</span>
                  <span className="font-mono">20%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-primary/70 h-2 rounded-full" style={{ width: '20%' }} />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
