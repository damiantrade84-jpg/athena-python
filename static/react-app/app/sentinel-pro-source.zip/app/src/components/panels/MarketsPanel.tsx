import { useStore } from '@/hooks/useStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  TrendingUp, TrendingDown, Minus, Search, BarChart3,
  DollarSign, Activity
} from 'lucide-react';

export default function MarketsPanel() {
  const { marketData } = useStore();

  const forex = marketData.filter(m => !m.pair.includes('XAU') && !m.pair.includes('XAG') && !m.pair.includes('BTC') && !m.pair.includes('ETH') && !m.pair.includes('SOL') && !m.pair.includes('BNB') && !m.pair.includes('US30') && !m.pair.includes('NAS') && !m.pair.includes('SPX'));
  const commodities = marketData.filter(m => m.pair.includes('XAU') || m.pair.includes('XAG'));
  const indices = marketData.filter(m => m.pair.includes('US30') || m.pair.includes('NAS') || m.pair.includes('SPX'));
  const crypto = marketData.filter(m => m.pair.includes('BTC') || m.pair.includes('ETH') || m.pair.includes('SOL') || m.pair.includes('BNB'));

  const MarketCard = ({ title, icon: Icon, data }: { title: string; icon: any; data: typeof marketData }) => (
    <Card className="border-border/60 bg-card/50">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold flex items-center gap-2">
          <Icon className="w-4 h-4 text-primary" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-1">
          {data.map(m => (
            <div key={m.pair} className="flex items-center justify-between p-2 rounded-md hover:bg-muted/30 transition-colors">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-medium w-16">{m.pair}</span>
                {m.change24h > 0.5 ? <TrendingUp className="w-3 h-3 text-long" /> :
                 m.change24h < -0.5 ? <TrendingDown className="w-3 h-3 text-short" /> :
                 <Minus className="w-3 h-3 text-muted-foreground" />}
              </div>
              <div className="flex items-center gap-4">
                <span className="text-xs font-mono">{m.price.toFixed(m.price > 1000 ? 2 : 5)}</span>
                <span className={`text-xs font-mono w-14 text-right ${m.change24h >= 0 ? 'text-long' : 'text-short'}`}>
                  {m.change24h >= 0 ? '+' : ''}{m.change24h.toFixed(2)}%
                </span>
                <span className="text-[10px] font-mono text-muted-foreground w-16 text-right">
                  {(m.volume24h / 1000).toFixed(0)}K
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-primary" />
          Market Overview
        </h2>
        <div className="relative w-56">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input placeholder="Search markets..." className="pl-8 h-8 text-xs" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <MarketCard title="Forex" icon={DollarSign} data={forex} />
        <MarketCard title="Commodities" icon={Activity} data={commodities} />
        <MarketCard title="Indices" icon={TrendingUp} data={indices} />
        <MarketCard title="Crypto" icon={BarChart3} data={crypto} />
      </div>
    </div>
  );
}
