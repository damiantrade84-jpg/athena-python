import { useState, useCallback, useMemo } from 'react';
import { useStore } from '@/hooks/useStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Search, Zap, BarChart3, Globe, BrainCircuit,
  Eye, Newspaper, GitCompare,
  Loader2, X, ArrowUpRight, ArrowDownRight,
  Sparkles, Layers, Crosshair, RefreshCw
} from 'lucide-react';
import type {
  Pair, EngineAResult, EngineBResult, CompareResult,
  NewsResult, VisionResult, PBState
} from '@/types/pairBrowser';

const PAIRS: Pair[] = [
  { symbol: 'EURUSD', display: 'EUR/USD', enabled: true, type: 'forex', group: 'Forex' },
  { symbol: 'GBPUSD', display: 'GBP/USD', enabled: true, type: 'forex', group: 'Forex' },
  { symbol: 'USDJPY', display: 'USD/JPY', enabled: true, type: 'forex', group: 'Forex' },
  { symbol: 'AUDUSD', display: 'AUD/USD', enabled: true, type: 'forex', group: 'Forex' },
  { symbol: 'USDCAD', display: 'USD/CAD', enabled: true, type: 'forex', group: 'Forex' },
  { symbol: 'USDCHF', display: 'USD/CHF', enabled: true, type: 'forex', group: 'Forex' },
  { symbol: 'NZDUSD', display: 'NZD/USD', enabled: true, type: 'forex', group: 'Forex' },
  { symbol: 'EURGBP', display: 'EUR/GBP', enabled: true, type: 'forex', group: 'Forex' },
  { symbol: 'XAUUSD', display: 'XAU/USD', enabled: true, type: 'commodity', group: 'Commodities' },
  { symbol: 'XAGUSD', display: 'XAG/USD', enabled: true, type: 'commodity', group: 'Commodities' },
  { symbol: 'BTCUSD', display: 'BTC/USD', enabled: true, type: 'crypto', group: 'Crypto' },
  { symbol: 'ETHUSD', display: 'ETH/USD', enabled: true, type: 'crypto', group: 'Crypto' },
  { symbol: 'SOLUSD', display: 'SOL/USD', enabled: true, type: 'crypto', group: 'Crypto' },
  { symbol: 'US30', display: 'US30', enabled: true, type: 'index', group: 'Indices' },
  { symbol: 'NAS100', display: 'NAS100', enabled: true, type: 'index', group: 'Indices' },
  { symbol: 'SPX500', display: 'SPX500', enabled: true, type: 'index', group: 'Indices' },
  { symbol: 'AAPL', display: 'AAPL', enabled: false, type: 'stock', group: 'US Stocks' },
  { symbol: 'MSFT', display: 'MSFT', enabled: false, type: 'stock', group: 'US Stocks' },
  { symbol: 'NVDA', display: 'NVDA', enabled: false, type: 'stock', group: 'US Stocks' },
  { symbol: 'TSLA', display: 'TSLA', enabled: false, type: 'stock', group: 'US Stocks' },
  { symbol: 'AMD', display: 'AMD', enabled: false, type: 'stock', group: 'US Stocks' },
  { symbol: 'AMZN', display: 'AMZN', enabled: false, type: 'stock', group: 'US Stocks' },
];

function fmtPrice(value: number | string | null | undefined, _sig?: { type?: string }) {
  if (value == null || value === '') return 'n/a';
  const n = parseFloat(String(value));
  if (isNaN(n)) return 'n/a';
  if (n >= 10000) return n.toLocaleString(undefined, { maximumFractionDigits: 1 });
  if (n >= 100) return n.toLocaleString(undefined, { maximumFractionDigits: 2 });
  if (n >= 1) return n.toFixed(4);
  return n.toPrecision(5);
}

function fmtNum(value: number | string | undefined, digits = 2) {
  const n = Number(value);
  return isFinite(n) ? n.toFixed(digits) : 'n/a';
}

function Metric({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div className="p-2.5 rounded-md bg-muted/30">
      <div className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</div>
      <div className="text-xs font-mono font-semibold mt-0.5" style={color ? { color } : undefined}>{value}</div>
    </div>
  );
}

function Section({ title, children, icon: Icon }: { title: string; children: React.ReactNode; icon?: React.ElementType }) {
  return (
    <Card className="border-border/60 bg-card/50">
      <CardHeader className="pb-2">
        <CardTitle className="text-xs font-semibold flex items-center gap-2 uppercase tracking-wider">
          {Icon && <Icon className="w-3.5 h-3.5 text-primary" />}
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">{children}</CardContent>
    </Card>
  );
}

export default function PairBrowserPanel() {
  const { getLivePrice, showToast } = useStore();
  const [state, setState] = useState<PBState>({
    pairs: PAIRS,
    selectedSymbol: '',
    assetClass: '',
    query: '',
    style: 'auto',
    directionMode: 'auto',
    filters: { news: true, inter: true, graph: true, aiVision: true },
    engineA: null,
    engineB: null,
    compare: null,
    news: null,
    vision: null,
    intermarket: null,
    intermarketError: '',
    intermarketLoading: false,
    loadedPairs: true,
    loadingPairs: false,
    manualDir: 'LONG',
    manualStyle: 'swing',
  });

  const [runningA, setRunningA] = useState(false);
  const [runningB, setRunningB] = useState(false);
  const [runningCompare, setRunningCompare] = useState(false);
  const [runningNews, setRunningNews] = useState(false);
  const [runningVision, setRunningVision] = useState(false);

  const selectedPair = useMemo(
    () => state.pairs.find(p => p.symbol === state.selectedSymbol) || null,
    [state.pairs, state.selectedSymbol]
  );

  const livePrice = selectedPair ? getLivePrice(selectedPair.display) : null;

  const visiblePairs = useMemo(() => {
    const needle = state.query.trim().toLowerCase();
    return state.pairs.filter(p => {
      if (state.assetClass && p.type !== state.assetClass) return false;
      if (!needle) return true;
      return p.display.toLowerCase().includes(needle) || p.symbol.toLowerCase().includes(needle);
    });
  }, [state.pairs, state.assetClass, state.query]);

  const update = useCallback((patch: Partial<PBState>) => {
    setState(prev => ({ ...prev, ...patch }));
  }, []);

  const selectPair = useCallback((symbol: string) => {
    setState(prev => {
      if (prev.selectedSymbol === symbol) return prev;
      return {
        ...prev,
        selectedSymbol: symbol,
        engineA: null, engineB: null, compare: null, news: null, vision: null,
      };
    });
  }, []);

  const runEngineA = useCallback(async () => {
    if (!selectedPair) { showToast('Select a pair first', 'error'); return; }
    setRunningA(true);
    try {
      await new Promise(r => setTimeout(r, 800));
      const mock: EngineAResult = {
        direction: Math.random() > 0.5 ? 'LONG' : 'SHORT',
        confluenceScore: Math.random() * 10,
        maxScore: 10,
        threshold: 6,
        passed: Math.random() > 0.3,
        conviction: ['STRONG', 'MODERATE', 'WEAK'][Math.floor(Math.random() * 3)],
        entry: 1.0845 + Math.random() * 0.01,
        sl: 1.0820,
        tp1: 1.0890,
        tp2: 1.0910,
        tp3: 1.0930,
        regimeName: 'TRENDING',
        trendState: 'BULLISH',
        is_forming: Math.random() > 0.7,
        session: { name: 'London' },
        symbol: selectedPair.symbol,
        type: selectedPair.type,
      };
      update({ engineA: mock, engineB: null, compare: null, vision: null });
      showToast(`Engine A scan ready for ${selectedPair.display}`, 'success');
    } catch (err) {
      showToast('Engine A failed', 'error');
    } finally { setRunningA(false); }
  }, [selectedPair, update, showToast]);

  const runEngineB = useCallback(async () => {
    if (!selectedPair) { showToast('Select a pair first', 'error'); return; }
    if (state.directionMode === 'auto' && !state.engineA) {
      await runEngineA();
    }
    setRunningB(true);
    try {
      await new Promise(r => setTimeout(r, 800));
      const mock: EngineBResult = {
        direction: state.engineA?.direction || (Math.random() > 0.5 ? 'LONG' : 'SHORT'),
        current_swing_sequence: 'HH-HL-HH',
        macro_swing_sequence: 'LL-LH-LL',
        confluenceScore: 7.5,
        passed: Math.random() > 0.3,
        style: state.style || 'swing',
        current_price: livePrice || 1.0850,
        recommended_stop_loss: (livePrice || 1.0850) - 0.002,
        recommended_take_profit: (livePrice || 1.0850) + 0.005,
        rr: 2.5,
        type: selectedPair.type,
      };
      update({ engineB: mock, compare: null, vision: null });
      showToast(`Engine B scan ready for ${selectedPair.display}`, 'success');
    } catch (err) {
      showToast('Engine B failed', 'error');
    } finally { setRunningB(false); }
  }, [selectedPair, state.directionMode, state.engineA, state.style, livePrice, update, showToast, runEngineA]);

  const runCompare = useCallback(async () => {
    if (!selectedPair) { showToast('Select a pair first', 'error'); return; }
    setRunningCompare(true);
    try {
      await new Promise(r => setTimeout(r, 800));
      const a = state.engineA;
      const b = state.engineB;
      const sameDir = a?.direction === b?.direction;
      const mock: CompareResult = {
        summary: {
          verdict: sameDir ? 'ALIGNED' : 'MISALIGNED',
          sameDirection: sameDir,
          structureAligned: sameDir,
          macroAligned: sameDir,
          engineAStyle: 'trend',
          engineBStyle: 'structure',
          engineBMinScore: 6.5,
          aiReviewIncluded: false,
        },
        engineA: a || undefined,
        engineB: b || undefined,
      };
      update({ compare: mock, vision: null });
      showToast(`Compare ready for ${selectedPair.display}`, 'success');
    } catch (err) {
      showToast('Compare failed', 'error');
    } finally { setRunningCompare(false); }
  }, [selectedPair, state.engineA, state.engineB, update, showToast]);

  const runNews = useCallback(async () => {
    if (!selectedPair) { showToast('Select a pair first', 'error'); return; }
    setRunningNews(true);
    try {
      await new Promise(r => setTimeout(r, 600));
      const mock: NewsResult = {
        structured: {
          direction: Math.random() > 0.5 ? 'bullish' : 'bearish',
          sentiment_score: (Math.random() - 0.5) * 2,
          confidence: 0.72,
          major_event_detected: Math.random() > 0.8,
          key_themes: ['Fed Policy', 'Inflation Data', 'Employment'],
          article_count_used: 24,
        },
        confluenceVote: 0.65,
        eodhdTicker: selectedPair.symbol,
      };
      update({ news: mock });
      showToast(`News sentiment ready for ${selectedPair.display}`, 'success');
    } catch (err) {
      showToast('News sentiment failed', 'error');
    } finally { setRunningNews(false); }
  }, [selectedPair, update, showToast]);

  const runVision = useCallback(async () => {
    if (!selectedPair) { showToast('Select a pair first', 'error'); return; }
    if (!state.engineA) { showToast('Run Engine A first', 'error'); return; }
    setRunningVision(true);
    try {
      await new Promise(r => setTimeout(r, 1200));
      const mock: VisionResult = {
        model: 'claude-3-sonnet',
        tf: 'H4',
        structured: {
          rating: ['STRONG', 'MODERATE', 'WEAK', 'CONTRADICTS'][Math.floor(Math.random() * 4)],
          confirms_direction: Math.random() > 0.3,
          right_edge_status: ['FAVORABLE', 'NEUTRAL', 'UNFAVORABLE'][Math.floor(Math.random() * 3)],
          style_ratings: {
            scalp: ['A', 'B', 'C', 'D'][Math.floor(Math.random() * 4)],
            intraday: ['A', 'B', 'C', 'D'][Math.floor(Math.random() * 4)],
            swing: ['A', 'B', 'C'][Math.floor(Math.random() * 3)],
          },
        },
        analysis: `Chart analysis for ${selectedPair.display}: Price action shows clear ${state.engineA?.direction === 'LONG' ? 'bullish' : 'bearish'} momentum with volume confirmation. The structure exhibits a well-defined ${state.engineA?.direction === 'LONG' ? 'higher high/higher low' : 'lower low/lower high'} pattern. Key level at ${fmtPrice(state.engineA?.entry)} acts as ${state.engineA?.direction === 'LONG' ? 'support' : 'resistance'}. Risk-reward profile is favorable at current levels.`,
      };
      update({ vision: mock });
      showToast(`AI vision ready for ${selectedPair.display}`, 'success');
    } catch (err) {
      showToast('AI vision failed', 'error');
    } finally { setRunningVision(false); }
  }, [selectedPair, state.engineA, update, showToast]);

  const manualExecute = useCallback(async () => {
    if (!selectedPair) { showToast('Select a pair first', 'error'); return; }
    showToast(`${state.manualDir} ${selectedPair.display} executed (${state.manualStyle})`, 'success');
  }, [selectedPair, state.manualDir, state.manualStyle, showToast]);

  // ── Render ───────────────────────────────────────────────────────────────
  return (
    <div className="flex gap-4 h-[calc(100vh-110px)]">
      {/* Left Sidebar — Pair List */}
      <Card className="w-[260px] shrink-0 border-border/60 bg-card/50 flex flex-col">
        <CardHeader className="pb-2 space-y-2">
          <CardTitle className="text-xs font-semibold flex items-center gap-2 uppercase tracking-wider">
            <Layers className="w-3.5 h-3.5 text-primary" />
            Pair Browser
          </CardTitle>
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              placeholder="Search pairs..."
              className="pl-8 h-7 text-xs"
              value={state.query}
              onChange={e => update({ query: e.target.value })}
            />
          </div>
          <div className="flex gap-1.5">
            <Select value={state.assetClass} onValueChange={v => update({ assetClass: v })}>
              <SelectTrigger className="h-6 text-[10px] flex-1"><SelectValue placeholder="All" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="" className="text-xs">All Types</SelectItem>
                <SelectItem value="forex" className="text-xs">Forex</SelectItem>
                <SelectItem value="crypto" className="text-xs">Crypto</SelectItem>
                <SelectItem value="commodity" className="text-xs">Commodity</SelectItem>
                <SelectItem value="index" className="text-xs">Index</SelectItem>
                <SelectItem value="stock" className="text-xs">Stocks</SelectItem>
              </SelectContent>
            </Select>
            <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => update({ query: '', assetClass: '' })}>
              <X className="w-3 h-3" />
            </Button>
          </div>
          <div className="text-[10px] text-muted-foreground font-mono">{visiblePairs.length} pairs</div>
        </CardHeader>
        <CardContent className="flex-1 min-h-0 p-0 px-4 pb-4">
          <ScrollArea className="h-full">
            <div className="space-y-0.5">
              {visiblePairs.map(pair => (
                <button
                  key={pair.symbol}
                  onClick={() => selectPair(pair.symbol)}
                  className={`w-full flex items-center justify-between p-2 rounded-md text-left transition-colors ${
                    selectedPair?.symbol === pair.symbol
                      ? 'bg-primary/15 border border-primary/30'
                      : 'hover:bg-muted/30 border border-transparent'
                  }`}
                >
                  <div>
                    <div className="text-xs font-medium">{pair.display}</div>
                    <div className="text-[10px] text-muted-foreground font-mono">{pair.type.toUpperCase()} | {pair.group}</div>
                  </div>
                  <Badge variant={pair.enabled ? 'default' : 'secondary'} className="text-[9px] h-4 px-1">
                    {pair.enabled ? 'ACTIVE' : 'WATCH'}
                  </Badge>
                </button>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Right Main Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <Card className="border-border/60 bg-card/50 mb-3">
          <CardContent className="p-3">
            {selectedPair ? (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-mono font-bold">{selectedPair.display}</span>
                      <Badge variant={selectedPair.enabled ? 'default' : 'secondary'} className="text-[9px] h-4">
                        {selectedPair.enabled ? 'ACTIVE' : 'WATCH'}
                      </Badge>
                      {state.engineA?.direction && (
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                          state.engineA.direction === 'LONG' ? 'bg-long/20 text-long' : 'bg-short/20 text-short'
                        }`}>
                          {state.engineA.direction}
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">
                      {selectedPair.type.toUpperCase()} | {selectedPair.symbol} | Style: {state.style.toUpperCase()} | Dir: {state.directionMode.toUpperCase()}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-mono font-bold">{fmtPrice(livePrice)}</div>
                  <div className="text-[10px] text-muted-foreground">Live price</div>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center">
                  <Layers className="w-4 h-4 text-muted-foreground" />
                </div>
                <div>
                  <div className="text-sm font-semibold">Select a pair</div>
                  <div className="text-[10px] text-muted-foreground">Choose a pair to run Engine A, Engine B, Compare, or AI Vision</div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Action Toolbar */}
        {selectedPair && (
          <div className="flex items-center gap-1.5 mb-3 flex-wrap">
            <Button size="sm" className="h-7 text-[10px] gap-1" onClick={runEngineA} disabled={runningA}>
              {runningA ? <Loader2 className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
              ENGINE A
            </Button>
            <Button size="sm" className="h-7 text-[10px] gap-1" onClick={runEngineB} disabled={runningB || !selectedPair}>
              {runningB ? <Loader2 className="w-3 h-3 animate-spin" /> : <Crosshair className="w-3 h-3" />}
              ENGINE B
            </Button>
            <Button size="sm" className="h-7 text-[10px] gap-1" onClick={runCompare} disabled={runningCompare}>
              {runningCompare ? <Loader2 className="w-3 h-3 animate-spin" /> : <GitCompare className="w-3 h-3" />}
              COMPARE
            </Button>
            <Button size="sm" variant="outline" className="h-7 text-[10px] gap-1" onClick={runNews} disabled={runningNews}>
              {runningNews ? <Loader2 className="w-3 h-3 animate-spin" /> : <Newspaper className="w-3 h-3" />}
              NEWS
            </Button>
            <Button size="sm" variant="outline" className="h-7 text-[10px] gap-1" onClick={runVision} disabled={runningVision || !state.engineA}>
              {runningVision ? <Loader2 className="w-3 h-3 animate-spin" /> : <Eye className="w-3 h-3" />}
              AI VISION
            </Button>
            <Separator orientation="vertical" className="h-5 mx-1" />
            <Select value={state.style} onValueChange={v => update({ style: v })}>
              <SelectTrigger className="w-[80px] h-7 text-[10px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="auto" className="text-xs">AUTO</SelectItem>
                <SelectItem value="scalp" className="text-xs">SCALP</SelectItem>
                <SelectItem value="intraday" className="text-xs">INTRADAY</SelectItem>
                <SelectItem value="swing" className="text-xs">SWING</SelectItem>
              </SelectContent>
            </Select>
            <Select value={state.directionMode} onValueChange={v => update({ directionMode: v })}>
              <SelectTrigger className="w-[80px] h-7 text-[10px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="auto" className="text-xs">AUTO</SelectItem>
                <SelectItem value="LONG" className="text-xs">LONG</SelectItem>
                <SelectItem value="SHORT" className="text-xs">SHORT</SelectItem>
              </SelectContent>
            </Select>
            <Separator orientation="vertical" className="h-5 mx-1" />
            {(['news', 'inter', 'graph', 'aiVision'] as const).map(f => (
              <Button
                key={f}
                size="sm"
                variant={state.filters[f] ? 'default' : 'ghost'}
                className="h-7 text-[9px] px-2"
                onClick={() => update({ filters: { ...state.filters, [f]: !state.filters[f] } })}
              >
                {f === 'news' && <Newspaper className="w-3 h-3 mr-1" />}
                {f === 'inter' && <Globe className="w-3 h-3 mr-1" />}
                {f === 'graph' && <BarChart3 className="w-3 h-3 mr-1" />}
                {f === 'aiVision' && <Eye className="w-3 h-3 mr-1" />}
                {f.toUpperCase()}
              </Button>
            ))}
          </div>
        )}

        {/* Sections */}
        {selectedPair ? (
          <ScrollArea className="flex-1">
            <div className="space-y-3 pr-2">
              {/* EXECUTE */}
              <Section title="Execute" icon={Sparkles}>
                <div className="space-y-3">
                  <div>
                    <div className="text-[10px] text-muted-foreground mb-1.5 uppercase tracking-wider">Direction</div>
                    <div className="flex gap-2">
                      {['LONG', 'SHORT'].map(d => (
                        <Button
                          key={d}
                          size="sm"
                          variant={state.manualDir === d ? 'default' : 'outline'}
                          className={`flex-1 h-8 text-xs font-bold ${
                            state.manualDir === d
                              ? d === 'LONG' ? 'bg-long/20 text-long hover:bg-long/30 border-long/40' : 'bg-short/20 text-short hover:bg-short/30 border-short/40'
                              : ''
                          }`}
                          onClick={() => update({ manualDir: d })}
                        >
                          {d === 'LONG' ? <ArrowUpRight className="w-3.5 h-3.5 mr-1" /> : <ArrowDownRight className="w-3.5 h-3.5 mr-1" />}
                          {d}
                        </Button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-muted-foreground mb-1.5 uppercase tracking-wider">Style</div>
                    <div className="flex gap-2">
                      {[
                        { v: 'scalp', label: 'SCALP', tip: 'M15 — tight SL/TP' },
                        { v: 'intraday', label: 'INTRADAY', tip: 'H1 — medium SL/TP' },
                        { v: 'swing', label: 'SWING', tip: 'H4/D1 — wide SL/TP' },
                      ].map(s => (
                        <Button
                          key={s.v}
                          size="sm"
                          variant={state.manualStyle === s.v ? 'default' : 'outline'}
                          className={`flex-1 h-8 text-[10px] font-bold ${
                            state.manualStyle === s.v ? 'bg-primary/20 text-primary hover:bg-primary/30 border-primary/40' : ''
                          }`}
                          title={s.tip}
                          onClick={() => update({ manualStyle: s.v })}
                        >
                          {s.label}
                        </Button>
                      ))}
                    </div>
                  </div>
                  <div className="text-[10px] text-muted-foreground p-2.5 rounded-md bg-muted/30 border border-border/40 leading-relaxed">
                    SL/TP auto-calculated from ATR for the selected style at execution time. Position size uses the global risk sizing slider.
                  </div>
                  <Button className="w-full gap-2 h-10 font-bold text-sm" onClick={manualExecute}>
                    <Zap className="w-4 h-4" />
                    EXECUTE {state.manualDir} — {state.manualStyle.toUpperCase()}
                  </Button>
                </div>
              </Section>

              {/* ENGINE A */}
              {state.engineA ? (
                <Section title="Engine A — Factor Model" icon={Zap}>
                  <div className="grid grid-cols-4 gap-2">
                    <Metric label="Direction" value={state.engineA.direction || 'n/a'} color={state.engineA.direction === 'LONG' ? 'hsl(var(--long))' : state.engineA.direction === 'SHORT' ? 'hsl(var(--short))' : undefined} />
                    <Metric label="Score" value={`${fmtNum(state.engineA.confluenceScore, 2)}/${state.engineA.maxScore}`} color={state.engineA.passed ? 'hsl(var(--long))' : 'hsl(var(--short))'} />
                    <Metric label="Entry" value={fmtPrice(state.engineA.entry, state.engineA)} />
                    <Metric label="Stop Loss" value={fmtPrice(state.engineA.sl, state.engineA)} color="hsl(var(--short))" />
                    <Metric label="Take Profit" value={fmtPrice(state.engineA.tp1, state.engineA)} color="hsl(var(--long))" />
                    <Metric label="TP2" value={fmtPrice(state.engineA.tp2, state.engineA)} color="hsl(var(--long))" />
                    <Metric label="TP3" value={fmtPrice(state.engineA.tp3, state.engineA)} color="hsl(var(--long))" />
                    <Metric label="Conviction" value={String(state.engineA.conviction || 'n/a')} />
                    <Metric label="Regime" value={state.engineA.regimeName || 'n/a'} />
                    <Metric label="Session" value={state.engineA.session?.name || 'n/a'} />
                    <Metric label="State" value={state.engineA.is_forming ? 'FORMING' : 'CONFIRMED'} color={state.engineA.is_forming ? 'hsl(var(--warning))' : 'hsl(var(--long))'} />
                    <Metric label="Threshold" value={fmtNum(state.engineA.threshold, 1)} />
                  </div>
                  {state.engineA.aiAnalysis && (
                    <div className="mt-3 p-3 rounded-md bg-muted/30 text-xs leading-relaxed">{state.engineA.aiAnalysis}</div>
                  )}
                </Section>
              ) : (
                <Section title="Engine A — Factor Model" icon={Zap}>
                  <div className="text-xs text-muted-foreground py-4 text-center">
                    Run Engine A to load direction, confluence, levels, and signal context for this pair.
                  </div>
                </Section>
              )}

              {/* ENGINE B */}
              {state.engineB ? (
                <Section title="Engine B — Naked Structure" icon={Crosshair}>
                  <div className="grid grid-cols-4 gap-2">
                    <Metric label="Direction" value={state.engineB.direction || 'n/a'} color={state.engineB.direction === 'LONG' ? 'hsl(var(--long))' : state.engineB.direction === 'SHORT' ? 'hsl(var(--short))' : undefined} />
                    <Metric label="Structure" value={state.engineB.current_swing_sequence || 'n/a'} />
                    <Metric label="Macro" value={state.engineB.macro_swing_sequence || 'n/a'} />
                    <Metric label="Checklist" value={state.engineB.passed ? 'PASS' : 'FAIL'} color={state.engineB.passed ? 'hsl(var(--long))' : 'hsl(var(--short))'} />
                    <Metric label="Current Price" value={fmtPrice(state.engineB.current_price, state.engineB)} />
                    <Metric label="Stop Loss" value={fmtPrice(state.engineB.recommended_stop_loss || state.engineB.stop_loss || state.engineB.sl, state.engineB)} color="hsl(var(--short))" />
                    <Metric label="Take Profit" value={fmtPrice(state.engineB.recommended_take_profit || state.engineB.take_profit || state.engineB.tp1 || state.engineB.tp, state.engineB)} color="hsl(var(--long))" />
                    <Metric label="R:R" value={state.engineB.rr != null ? `${fmtNum(state.engineB.rr, 2)}R` : 'n/a'} />
                  </div>
                  {state.engineB.ai_analysis && (
                    <div className="mt-3 p-3 rounded-md bg-muted/30 text-xs leading-relaxed">{state.engineB.ai_analysis}</div>
                  )}
                </Section>
              ) : (
                <Section title="Engine B — Naked Structure" icon={Crosshair}>
                  <div className="text-xs text-muted-foreground py-4 text-center">
                    Run Engine B to inspect live structure, confidence, and AI feedback for this pair.
                  </div>
                </Section>
              )}

              {/* COMPARE */}
              {state.compare ? (
                <Section title="Compare A vs B" icon={GitCompare}>
                  <div className="grid grid-cols-4 gap-2 mb-3">
                    <Metric label="Verdict" value={state.compare.summary?.verdict || 'n/a'} color={state.compare.summary?.verdict === 'ALIGNED' ? 'hsl(var(--long))' : 'hsl(var(--short))'} />
                    <Metric label="Same Direction" value={state.compare.summary?.sameDirection ? 'YES' : 'NO'} color={state.compare.summary?.sameDirection ? 'hsl(var(--long))' : 'hsl(var(--short))'} />
                    <Metric label="Structure" value={state.compare.summary?.structureAligned ? 'YES' : 'NO'} color={state.compare.summary?.structureAligned ? 'hsl(var(--long))' : 'hsl(var(--short))'} />
                    <Metric label="Macro" value={state.compare.summary?.macroAligned ? 'YES' : 'NO'} color={state.compare.summary?.macroAligned ? 'hsl(var(--long))' : 'hsl(var(--short))'} />
                  </div>
                  <div className="overflow-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="border-b border-border/60">
                          <th className="text-left p-2 text-[10px] uppercase text-muted-foreground">Metric</th>
                          <th className="text-left p-2 text-[10px] uppercase text-muted-foreground">Engine A</th>
                          <th className="text-left p-2 text-[10px] uppercase text-muted-foreground">Engine B</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b border-border/30"><td className="p-2 text-muted-foreground">Direction</td><td className="p-2 font-mono">{state.compare.engineA?.direction || 'n/a'}</td><td className="p-2 font-mono">{state.compare.engineB?.direction || 'n/a'}</td></tr>
                        <tr className="border-b border-border/30"><td className="p-2 text-muted-foreground">Entry</td><td className="p-2 font-mono">{fmtPrice(state.compare.engineA?.entry, state.compare.engineA)}</td><td className="p-2 font-mono">{fmtPrice(state.compare.engineB?.current_price, state.compare.engineB)}</td></tr>
                        <tr className="border-b border-border/30"><td className="p-2 text-muted-foreground">Stop Loss</td><td className="p-2 font-mono">{fmtPrice(state.compare.engineA?.sl, state.compare.engineA)}</td><td className="p-2 font-mono">{fmtPrice(state.compare.engineB?.recommended_stop_loss || state.compare.engineB?.sl, state.compare.engineB)}</td></tr>
                        <tr className="border-b border-border/30"><td className="p-2 text-muted-foreground">Take Profit</td><td className="p-2 font-mono">{fmtPrice(state.compare.engineA?.tp1, state.compare.engineA)}</td><td className="p-2 font-mono">{fmtPrice(state.compare.engineB?.recommended_take_profit || state.compare.engineB?.tp1, state.compare.engineB)}</td></tr>
                      </tbody>
                    </table>
                  </div>
                </Section>
              ) : (
                <Section title="Compare A vs B" icon={GitCompare}>
                  <div className="text-xs text-muted-foreground py-4 text-center">
                    Run Compare to verify Engine B alignment with Engine A.
                  </div>
                </Section>
              )}

              {/* GRAPH */}
              {state.filters.graph && (
                <Section title="Graph" icon={BarChart3}>
                  <div className="grid grid-cols-4 gap-2">
                    <Metric label="Pair" value={selectedPair.display} />
                    <Metric label="Latest Price" value={fmtPrice(livePrice)} />
                    <Metric label="Engine A Entry" value={state.engineA ? fmtPrice(state.engineA.entry, state.engineA) : 'n/a'} />
                    <Metric label="Chart AI" value={state.vision ? 'LOADED' : 'NOT RUN'} color={state.vision ? 'hsl(var(--long))' : 'hsl(var(--accent))'} />
                  </div>
                </Section>
              )}

              {/* NEWS */}
              {state.filters.news && (
                state.news ? (
                  <Section title="News Sentiment" icon={Newspaper}>
                    <div className="grid grid-cols-4 gap-2 mb-3">
                      <Metric label="Direction" value={state.news.structured?.direction || 'n/a'} color={state.news.structured?.direction === 'bullish' ? 'hsl(var(--long))' : state.news.structured?.direction === 'bearish' ? 'hsl(var(--short))' : undefined} />
                      <Metric label="Sentiment" value={state.news.structured?.sentiment_score != null ? fmtNum(state.news.structured.sentiment_score, 2) : 'n/a'} />
                      <Metric label="Confidence" value={state.news.structured?.confidence != null ? `${fmtNum(Number(state.news.structured.confidence) * 100, 1)}%` : 'n/a'} />
                      <Metric label="Articles" value={String(state.news.structured?.article_count_used || 'n/a')} />
                    </div>
                    {state.news.structured?.key_themes && (
                      <div className="flex flex-wrap gap-1.5">
                        {state.news.structured.key_themes.map(t => (
                          <Badge key={t} variant="secondary" className="text-[9px]">{t}</Badge>
                        ))}
                      </div>
                    )}
                    {state.news.structured?.reasoning_summary && (
                      <div className="mt-3 p-3 rounded-md bg-muted/30 text-xs leading-relaxed">{state.news.structured.reasoning_summary}</div>
                    )}
                  </Section>
                ) : (
                  <Section title="News Sentiment" icon={Newspaper}>
                    <div className="flex items-center justify-between py-2">
                      <span className="text-xs text-muted-foreground">Load structured news sentiment for this pair.</span>
                      <Button size="sm" variant="outline" className="h-7 text-[10px] gap-1" onClick={runNews} disabled={runningNews}>
                        {runningNews ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
                        LOAD NEWS
                      </Button>
                    </div>
                  </Section>
                )
              )}

              {/* AI VISION */}
              {state.filters.aiVision && (
                state.vision ? (
                  <Section title="AI Vision — Chart Analysis" icon={Eye}>
                    <div className="grid grid-cols-4 gap-2 mb-3">
                      <Metric label="Model" value={state.vision.model || 'n/a'} />
                      <Metric label="Timeframe" value={state.vision.tf || 'n/a'} />
                      <Metric label="Rating" value={state.vision.structured?.rating || 'n/a'} color={state.vision.structured?.rating === 'STRONG' ? 'hsl(var(--long))' : state.vision.structured?.rating === 'CONTRADICTS' ? 'hsl(var(--short))' : 'hsl(var(--warning))'} />
                      <Metric label="Direction Check" value={state.vision.structured?.confirms_direction === false ? 'CONTRADICTS' : 'CONFIRMS'} color={state.vision.structured?.confirms_direction === false ? 'hsl(var(--short))' : 'hsl(var(--long))'} />
                    </div>
                    <div className="grid grid-cols-3 gap-2 mb-3">
                      <Metric label="Scalp" value={String(state.vision.structured?.style_ratings?.scalp || 'n/a').toUpperCase()} />
                      <Metric label="Intraday" value={String(state.vision.structured?.style_ratings?.intraday || 'n/a').toUpperCase()} />
                      <Metric label="Swing" value={String(state.vision.structured?.style_ratings?.swing || 'n/a').toUpperCase()} />
                    </div>
                    <div className="p-3 rounded-md bg-muted/30 text-xs leading-relaxed whitespace-pre-wrap">{state.vision.analysis || 'No analysis text returned.'}</div>
                  </Section>
                ) : (
                  <Section title="AI Vision — Chart Analysis" icon={Eye}>
                    <div className="flex items-center justify-between py-2">
                      <span className="text-xs text-muted-foreground">Run AI vision to analyze chart context for this pair.</span>
                      <Button size="sm" variant="outline" className="h-7 text-[10px] gap-1" onClick={runVision} disabled={runningVision || !state.engineA}>
                        {runningVision ? <Loader2 className="w-3 h-3 animate-spin" /> : <BrainCircuit className="w-3 h-3" />}
                        RUN AI VISION
                      </Button>
                    </div>
                  </Section>
                )
              )}
            </div>
          </ScrollArea>
        ) : (
          <Card className="flex-1 border-border/60 bg-card/50 flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center mb-3">
              <Layers className="w-6 h-6 text-muted-foreground" />
            </div>
            <div className="text-sm font-semibold mb-1">Pair Workbench Ready</div>
            <div className="text-xs text-muted-foreground text-center max-w-sm">
              Select a pair to inspect its individual scan path, compare the engines, open the chart, and request AI feedback.
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
