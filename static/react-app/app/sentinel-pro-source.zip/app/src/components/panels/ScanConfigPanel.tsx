import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ENGINES, TIMEFRAMES, PAIRS } from '@/data/mockData';
import {
  Settings, Zap, TrendingUp, BarChart3, Volume2, Clock,
  Save, RotateCcw
} from 'lucide-react';

export default function ScanConfigPanel() {
  const [minConfidence, setMinConfidence] = useState([75]);
  const [minRR, setMinRR] = useState([2.0]);
  const [selectedEngines, setSelectedEngines] = useState<string[]>(['A', 'B', 'C']);
  const [selectedTimeframes, setSelectedTimeframes] = useState<string[]>(['M15', 'H1', 'H4']);
  const [selectedPairs, setSelectedPairs] = useState<string[]>(PAIRS.slice(0, 10));
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [requireConfirmation, setRequireConfirmation] = useState(true);
  const [newsFilter, setNewsFilter] = useState(true);

  const toggleEngine = (id: string) => {
    setSelectedEngines(prev =>
      prev.includes(id) ? prev.filter(e => e !== id) : [...prev, id]
    );
  };

  const toggleTimeframe = (tf: string) => {
    setSelectedTimeframes(prev =>
      prev.includes(tf) ? prev.filter(t => t !== tf) : [...prev, tf]
    );
  };

  const togglePair = (pair: string) => {
    setSelectedPairs(prev =>
      prev.includes(pair) ? prev.filter(p => p !== pair) : [...prev, pair]
    );
  };

  return (
    <div className="space-y-4 max-w-4xl">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold flex items-center gap-2">
          <Settings className="w-4 h-4 text-primary" />
          Scan Configuration
        </h2>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className="h-7 gap-1 text-xs">
            <RotateCcw className="w-3 h-3" />
            Reset
          </Button>
          <Button size="sm" className="h-7 gap-1 text-xs">
            <Save className="w-3 h-3" />
            Save Config
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Thresholds */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              Thresholds
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Minimum Confidence</Label>
                <Badge variant="outline" className="text-[10px] font-mono">{minConfidence[0]}%</Badge>
              </div>
              <Slider value={minConfidence} onValueChange={setMinConfidence} min={50} max={95} step={5} />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Minimum R:R Ratio</Label>
                <Badge variant="outline" className="text-[10px] font-mono">1:{minRR[0]}</Badge>
              </div>
              <Slider value={minRR} onValueChange={setMinRR} min={1.0} max={5.0} step={0.5} />
            </div>
          </CardContent>
        </Card>

        {/* Engines */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Zap className="w-4 h-4 text-primary" />
              Active Engines
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {ENGINES.map(engine => (
                <div
                  key={engine.id}
                  className={`flex items-center justify-between p-2.5 rounded-md border transition-colors cursor-pointer ${
                    selectedEngines.includes(engine.id)
                      ? 'border-primary/40 bg-primary/10'
                      : 'border-border/40 bg-muted/20 opacity-60'
                  }`}
                  onClick={() => toggleEngine(engine.id)}
                >
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${selectedEngines.includes(engine.id) ? 'bg-primary' : 'bg-muted-foreground/30'}`} />
                    <span className="text-xs font-medium">Engine {engine.id}</span>
                    <span className="text-[10px] text-muted-foreground">{engine.name}</span>
                  </div>
                  <Switch checked={selectedEngines.includes(engine.id)} />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Timeframes */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" />
              Timeframes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {TIMEFRAMES.map(tf => (
                <Button
                  key={tf}
                  size="sm"
                  variant={selectedTimeframes.includes(tf) ? 'default' : 'outline'}
                  className="h-7 text-[10px] font-mono"
                  onClick={() => toggleTimeframe(tf)}
                >
                  {tf}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Toggles */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-primary" />
              Options
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-xs">Auto Refresh</Label>
              <Switch checked={autoRefresh} onCheckedChange={setAutoRefresh} />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-xs">Require Confirmation</Label>
              <Switch checked={requireConfirmation} onCheckedChange={setRequireConfirmation} />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-xs">News Sentiment Filter</Label>
              <Switch checked={newsFilter} onCheckedChange={setNewsFilter} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pair Selection */}
      <Card className="border-border/60 bg-card/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-primary" />
            Watched Pairs ({selectedPairs.length}/{PAIRS.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {PAIRS.map(pair => (
              <Button
                key={pair}
                size="sm"
                variant={selectedPairs.includes(pair) ? 'default' : 'outline'}
                className="h-7 text-[10px] font-mono"
                onClick={() => togglePair(pair)}
              >
                {pair}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
