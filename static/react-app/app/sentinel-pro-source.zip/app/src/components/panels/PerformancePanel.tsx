import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  BarChart, Bar, Cell, PieChart, Pie,
  XAxis, YAxis, Tooltip, ResponsiveContainer,
} from 'recharts';
import { generatePerformanceMetrics } from '@/data/mockData';
import {
  TrendingUp, TrendingDown, Target, BarChart3, PieChartIcon, Activity,
  DollarSign, Percent, ArrowUpRight
} from 'lucide-react';

export default function PerformancePanel() {
  const metrics = generatePerformanceMetrics();

  const winColor = 'hsl(var(--long))';
  const lossColor = 'hsl(var(--short))';

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-primary" />
          Performance Analytics
        </h2>
        <Badge variant="outline" className="text-[10px]">YTD 2024</Badge>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-6 gap-3">
        {[
          { label: 'Total P&L', value: `$${metrics.totalPnl.toFixed(0)}`, icon: DollarSign, color: metrics.totalPnl >= 0 ? 'text-long' : 'text-short' },
          { label: 'Win Rate', value: `${metrics.winRate.toFixed(1)}%`, icon: Percent, color: 'text-primary' },
          { label: 'Profit Factor', value: metrics.profitFactor.toFixed(2), icon: Target, color: 'text-primary' },
          { label: 'Sharpe', value: metrics.sharpeRatio.toFixed(2), icon: BarChart3, color: 'text-primary' },
          { label: 'Max DD', value: `${metrics.maxDrawdown.toFixed(1)}%`, icon: TrendingDown, color: 'text-short' },
          { label: 'Total Trades', value: metrics.totalTrades.toString(), icon: Activity, color: 'text-primary' },
        ].map(m => (
          <Card key={m.label} className="border-border/60 bg-card/50">
            <CardContent className="p-3">
              <div className="flex items-center gap-2 mb-1">
                <m.icon className={`w-3.5 h-3.5 ${m.color}`} />
                <span className="text-[10px] text-muted-foreground uppercase">{m.label}</span>
              </div>
              <p className={`text-lg font-mono font-bold ${m.color}`}>{m.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Daily P&L */}
        <Card className="col-span-2 border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Activity className="w-4 h-4 text-primary" />
              Daily P&L
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[240px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={metrics.dailyPnl}>
                  <XAxis dataKey="date" tick={{ fontSize: 8, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} width={45} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px',
                      fontSize: '11px',
                    }}
                    formatter={(value: number) => [`$${value.toFixed(2)}`, 'P&L']}
                  />
                  <Bar dataKey="pnl" radius={[2, 2, 0, 0]}>
                    {metrics.dailyPnl.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.pnl >= 0 ? winColor : lossColor} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Monthly P&L */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-primary" />
              Monthly
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[240px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={metrics.monthlyPnl} layout="vertical">
                  <XAxis type="number" tick={{ fontSize: 8, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
                  <YAxis dataKey="month" type="category" tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} width={30} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px',
                      fontSize: '11px',
                    }}
                    formatter={(value: number) => [`$${value.toFixed(2)}`, 'P&L']}
                  />
                  <Bar dataKey="pnl" radius={[0, 2, 2, 0]}>
                    {metrics.monthlyPnl.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.pnl >= 0 ? winColor : lossColor} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Avg Win/Loss */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <ArrowUpRight className="w-4 h-4 text-long" />
              Avg Win vs Avg Loss
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-6">
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-long font-medium">Avg Win</span>
                  <span className="text-sm font-mono font-bold text-long">+${metrics.avgWin.toFixed(2)}</span>
                </div>
                <div className="w-full h-3 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-long rounded-full" style={{ width: '65%' }} />
                </div>
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-short font-medium">Avg Loss</span>
                  <span className="text-sm font-mono font-bold text-short">${metrics.avgLoss.toFixed(2)}</span>
                </div>
                <div className="w-full h-3 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-short rounded-full" style={{ width: '35%' }} />
                </div>
              </div>
            </div>
            <div className="mt-4 p-3 rounded-lg bg-muted/30">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Win/Loss Ratio</span>
                <span className="text-sm font-mono font-bold">{Math.abs(metrics.avgWin / metrics.avgLoss).toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* P&L by Pair */}
        <Card className="border-border/60 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <PieChartIcon className="w-4 h-4 text-primary" />
              P&L by Pair
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[180px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={metrics.byPair}
                    dataKey="pnl"
                    nameKey="pair"
                    cx="50%"
                    cy="50%"
                    outerRadius={70}
                    innerRadius={40}
                    strokeWidth={2}
                    stroke="hsl(var(--card))"
                  >
                    {metrics.byPair.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.pnl >= 0 ? winColor : lossColor} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px',
                      fontSize: '11px',
                    }}
                    formatter={(value: number) => [`$${value.toFixed(2)}`, 'P&L']}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {metrics.byPair.map(p => (
                <div key={p.pair} className="flex items-center gap-1">
                  <div className={`w-2 h-2 rounded-full ${p.pnl >= 0 ? 'bg-long' : 'bg-short'}`} />
                  <span className="text-[9px] font-mono">{p.pair}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
