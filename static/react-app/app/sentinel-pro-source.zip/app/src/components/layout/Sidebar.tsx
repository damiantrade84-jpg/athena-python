import { useStore } from '@/hooks/useStore';
import type { PanelId } from '@/types';
import { cn } from '@/lib/utils';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  LayoutDashboard, Radio, Search, Settings, ListOrdered,
  GitMerge, Timer, LineChart, History, Filter, Dices,
  FlaskConical, TrendingUp, BarChart3, ShieldCheck,
} from 'lucide-react';

const navItems: { id: PanelId; label: string; icon: React.ElementType; badge?: string }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'signals', label: 'Signals', icon: Radio, badge: 'LIVE' },
  { id: 'pairBrowser', label: 'Pair Browser', icon: Search },
  { id: 'scanConfig', label: 'Scan Config', icon: Settings },
  { id: 'trades', label: 'Trades', icon: ListOrdered },
  { id: 'engineC', label: 'Engine C', icon: GitMerge },
  { id: 'scalpLab', label: 'Scalp Lab', icon: Timer },
  { id: 'tvChart', label: 'TV Chart', icon: LineChart },
  { id: 'backtest', label: 'Backtest', icon: History },
  { id: 'screener', label: 'Screener', icon: Filter },
  { id: 'lotteryLab', label: 'Lottery Lab', icon: Dices },
  { id: 'researchLab', label: 'Research Lab', icon: FlaskConical },
  { id: 'performance', label: 'Performance', icon: TrendingUp },
  { id: 'markets', label: 'Markets', icon: BarChart3 },
  { id: 'guardian', label: 'Guardian', icon: ShieldCheck },
];

export default function Sidebar() {
  const { activePanel, setActivePanel, signals, positions, guardian } = useStore();

  const activeSignals = signals.filter(s => s.status === 'active').length;
  const openPositions = positions.filter(p => p.status === 'open').length;

  return (
    <aside className="w-[210px] shrink-0 border-r border-border/60 bg-sidebar flex flex-col">
      {/* Stats Bar */}
      <div className="p-3 border-b border-sidebar-border/40">
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-sidebar-accent/50 rounded-md p-2">
            <div className="text-[10px] text-sidebar-foreground/60 uppercase tracking-wider">Signals</div>
            <div className="text-lg font-mono font-bold text-primary leading-tight">{activeSignals}</div>
          </div>
          <div className="bg-sidebar-accent/50 rounded-md p-2">
            <div className="text-[10px] text-sidebar-foreground/60 uppercase tracking-wider">Positions</div>
            <div className="text-lg font-mono font-bold text-primary leading-tight">{openPositions}</div>
          </div>
          <div className="bg-sidebar-accent/50 rounded-md p-2">
            <div className="text-[10px] text-sidebar-foreground/60 uppercase tracking-wider">Daily P&L</div>
            <div className={`text-sm font-mono font-bold leading-tight ${guardian.dailyLoss >= 0 ? 'text-long' : 'text-short'}`}>
              {guardian.dailyLoss >= 0 ? '+' : ''}${guardian.dailyLoss.toFixed(0)}
            </div>
          </div>
          <div className="bg-sidebar-accent/50 rounded-md p-2">
            <div className="text-[10px] text-sidebar-foreground/60 uppercase tracking-wider">Win Rate</div>
            <div className="text-sm font-mono font-bold text-primary leading-tight">
              {(57.3).toFixed(1)}%
            </div>
          </div>
        </div>
      </div>

      <Separator className="bg-sidebar-border/40" />

      {/* Navigation */}
      <ScrollArea className="flex-1 py-2">
        <nav className="px-2 space-y-0.5">
          {navItems.map(item => {
            const isActive = activePanel === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActivePanel(item.id)}
                className={cn(
                  'w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-xs font-medium transition-all duration-150 group relative',
                  isActive
                    ? 'bg-sidebar-primary/15 text-sidebar-primary border-l-2 border-sidebar-primary'
                    : 'text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50 border-l-2 border-transparent'
                )}
              >
                <Icon className={cn(
                  'w-4 h-4 shrink-0 transition-colors',
                  isActive ? 'text-sidebar-primary' : 'text-sidebar-foreground/50 group-hover:text-sidebar-foreground/80'
                )} />
                <span className="flex-1 text-left">{item.label}</span>
                {item.badge && (
                  <Badge variant="outline" className="text-[9px] h-4 px-1 border-primary/40 text-primary bg-primary/10">
                    {item.badge}
                  </Badge>
                )}
                {item.id === 'signals' && activeSignals > 0 && (
                  <span className="w-4 h-4 rounded-full bg-primary/20 text-primary text-[9px] flex items-center justify-center font-mono">
                    {activeSignals}
                  </span>
                )}
                {item.id === 'trades' && openPositions > 0 && (
                  <span className="w-4 h-4 rounded-full bg-primary/20 text-primary text-[9px] flex items-center justify-center font-mono">
                    {openPositions}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </ScrollArea>

      <Separator className="bg-sidebar-border/40" />

      {/* Footer */}
      <div className="p-3">
        <div className="bg-sidebar-accent/30 rounded-md p-2.5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-sidebar-foreground/60">Circuit Breaker</span>
            <div className={`w-1.5 h-1.5 rounded-full ${guardian.circuitBreaker ? 'bg-short animate-pulse' : 'bg-long'}`} />
          </div>
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-sidebar-foreground/60">Daily Risk</span>
            <span className="text-[10px] font-mono text-sidebar-foreground/80">
              ${guardian.dailyLoss.toFixed(0)}/${guardian.dailyLossLimit}
            </span>
          </div>
          <div className="w-full bg-sidebar-border/30 rounded-full h-1 overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-500 bg-primary/70"
              style={{ width: `${Math.min(100, (Math.abs(guardian.dailyLoss) / guardian.dailyLossLimit) * 100)}%` }}
            />
          </div>
        </div>
      </div>
    </aside>
  );
}
