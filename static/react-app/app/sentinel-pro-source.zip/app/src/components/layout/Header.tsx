import { useStore } from '@/hooks/useStore';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import {
  Activity, Wifi, WifiOff, Zap, FlaskConical, RefreshCw,
  Bot, Shield
} from 'lucide-react';

export default function Header() {
  const {
    marketData, sessions, isAutoTrade, isTestMode,
    toggleAutoTrade, toggleTestMode, refreshSignals, guardian
  } = useStore();

  const activeSession = sessions.find(s => s.active);
  const connected = guardian.overall !== 'critical';

  return (
    <header className="h-14 border-b border-border/60 bg-card/50 backdrop-blur-xl flex items-center px-4 gap-4 shrink-0">
      {/* Logo */}
      <div className="flex items-center gap-2.5 min-w-[200px]">
        <div className="relative">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary/80 to-primary/40 flex items-center justify-center">
            <Activity className="w-4 h-4 text-primary-foreground" />
          </div>
          <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-primary animate-pulse" />
        </div>
        <div>
          <h1 className="text-sm font-bold tracking-tight leading-none">Sentinel Pro</h1>
          <span className="text-[10px] text-muted-foreground font-mono tracking-wider">v3.2.1</span>
        </div>
      </div>

      <Separator orientation="vertical" className="h-6" />

      {/* Live Ticker */}
      <div className="flex items-center gap-3 overflow-hidden flex-1">
        <div className="flex gap-3 animate-marquee whitespace-nowrap">
          {marketData.slice(0, 6).map(m => (
            <div key={m.pair} className="flex items-center gap-1.5 text-xs">
              <span className="font-mono font-semibold text-muted-foreground">{m.pair}</span>
              <span className="font-mono">{m.price.toFixed(m.price > 1000 ? 2 : 5)}</span>
              <span className={`font-mono ${m.change24h >= 0 ? 'text-long' : 'text-short'}`}>
                {m.change24h >= 0 ? '+' : ''}{m.change24h.toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      </div>

      <Separator orientation="vertical" className="h-6" />

      {/* Session Badge */}
      <div className="flex items-center gap-2">
        {activeSession && (
          <Badge variant="outline" className="text-[10px] font-mono border-primary/40 text-primary bg-primary/10">
            {activeSession.overlap || activeSession.session}
          </Badge>
        )}
        {connected ? (
          <Wifi className="w-3.5 h-3.5 text-long" />
        ) : (
          <WifiOff className="w-3.5 h-3.5 text-short" />
        )}
      </div>

      <Separator orientation="vertical" className="h-6" />

      {/* Controls */}
      <div className="flex items-center gap-1.5">
        <Button
          size="sm"
          variant={isTestMode ? 'default' : 'outline'}
          className="h-7 text-[10px] gap-1"
          onClick={toggleTestMode}
        >
          <FlaskConical className="w-3 h-3" />
          TEST
        </Button>
        <Button
          size="sm"
          variant={isAutoTrade ? 'default' : 'outline'}
          className="h-7 text-[10px] gap-1"
          onClick={toggleAutoTrade}
        >
          <Bot className="w-3 h-3" />
          BOT
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="h-7 text-[10px] gap-1"
          onClick={refreshSignals}
        >
          <RefreshCw className="w-3 h-3" />
          SCAN
        </Button>
      </div>

      {/* Guardian Status */}
      <div className="flex items-center gap-1.5">
        <Shield className={`w-3.5 h-3.5 ${
          guardian.overall === 'healthy' ? 'text-long' :
          guardian.overall === 'warning' ? 'text-warning' : 'text-short'
        }`} />
        <div className={`w-1.5 h-1.5 rounded-full ${
          guardian.overall === 'healthy' ? 'bg-long' :
          guardian.overall === 'warning' ? 'bg-warning' : 'bg-short'
        } ${guardian.overall === 'healthy' && 'animate-pulse'}`} />
      </div>

      {/* Quick Actions */}
      <div className="flex items-center gap-1.5">
        <Zap className="w-3.5 h-3.5 text-warning" />
      </div>
    </header>
  );
}
