export interface Signal {
  id: string;
  pair: string;
  direction: 'LONG' | 'SHORT';
  entry: number;
  sl: number;
  tp: number;
  tp2?: number;
  tp3?: number;
  confidence: number;
  engine: string;
  timeframe: string;
  rRatio: number;
  votes?: number;
  timestamp: string;
  livePrice?: number;
  pnl?: number;
  status: 'active' | 'closed' | 'pending';
  factors?: string[];
  notes?: string;
}

export interface Position {
  id: string;
  pair: string;
  direction: 'LONG' | 'SHORT';
  entry: number;
  size: number;
  sl: number;
  tp: number;
  pnl: number;
  pnlPercent: number;
  openTime: string;
  broker: 'MT5' | 'Bybit';
  type: 'market' | 'limit' | 'stop';
  status: 'open' | 'closed';
}

export interface MarketData {
  pair: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  spread: number;
}

export interface BacktestResult {
  id: string;
  name: string;
  pair: string;
  period: string;
  totalReturn: number;
  maxDrawdown: number;
  sharpe: number;
  winRate: number;
  profitFactor: number;
  trades: number;
  avgTrade: number;
  sqn: number;
  equityCurve: { date: string; equity: number }[];
}

export interface GuardianStatus {
  overall: 'healthy' | 'warning' | 'critical' | 'unknown';
  bootChecks: {
    name: string;
    status: 'pass' | 'fail' | 'pending';
    message: string;
  }[];
  circuitBreaker: boolean;
  dailyLoss: number;
  dailyLossLimit: number;
  openRisk: number;
  maxOpenRisk: number;
  divergence: boolean;
}

export interface ScreenerResult {
  pair: string;
  trend: 'bullish' | 'bearish' | 'neutral';
  strength: number;
  rsi: number;
  macd: number;
  volume: number;
  atr: number;
  sentiment: 'risk_on' | 'risk_off' | 'neutral';
}

export interface PerformanceMetrics {
  totalPnl: number;
  winRate: number;
  profitFactor: number;
  avgWin: number;
  avgLoss: number;
  maxDrawdown: number;
  sharpeRatio: number;
  totalTrades: number;
  dailyPnl: { date: string; pnl: number }[];
  monthlyPnl: { month: string; pnl: number }[];
  byPair: { pair: string; pnl: number; trades: number }[];
}

export type PanelId =
  | 'dashboard'
  | 'signals'
  | 'pairBrowser'
  | 'scanConfig'
  | 'trades'
  | 'engineC'
  | 'scalpLab'
  | 'tvChart'
  | 'backtest'
  | 'screener'
  | 'lotteryLab'
  | 'researchLab'
  | 'performance'
  | 'markets'
  | 'guardian';

export interface LotteryNumber {
  numbers: number[];
  date: string;
  game: string;
}

export interface LotteryAnalysis {
  hotNumbers: { number: number; frequency: number }[];
  coldNumbers: { number: number; frequency: number }[];
  overdueNumbers: { number: number; lastSeen: number }[];
  sumStats: { avg: number; min: number; max: number };
  oddEvenRatio: { odd: number; even: number };
}

export interface NewsItem {
  id: string;
  title: string;
  source: string;
  timestamp: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  impact: 'high' | 'medium' | 'low';
  currency: string;
}

export interface SessionHours {
  session: string;
  start: string;
  end: string;
  active: boolean;
  overlap?: string;
}
